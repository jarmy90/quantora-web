/quantora-workflow

Use the attached review bundle as implementation guidance, but verify every assumption against current `origin/main`. Do not overwrite newer work blindly.

## Objective

Repair Quantora production first, then expose the existing installation guide in a separate PR, and leave both changes fully validated and traceable.

## Phase 1: Vercel production repair

1. Read `README_FIRST.txt`, `CHANGE_PLAN.md`, both patches, and proposed files in this package.
2. Read repository workflow/Skill, MASTER, roadmap, package configuration, Vite configuration, Vercel scripts, and current GitHub/Vercel state.
3. Verify the current production 404 independently.
4. Create `fix/vercel-production-deployment` from updated `origin/main`.
5. Use the official TanStack Start + Nitro approach:
   - run `bun add -D nitro` and commit the resulting `package.json` and `bun.lock`;
   - register `nitro()` in `vite.config.ts` as shown in the proposal;
   - do not hand-edit `bun.lock`;
   - do not force a static export;
   - do not set a manual Vercel Output Directory unless current official behavior demonstrably requires it.
6. Treat `build-vercel.sh`, `vercel-entry.ts`, and `go-live.sh` as legacy/manual fallback until proven necessary. Do not delete them in this ticket unless they actively break Git deployment and tests cover the replacement.
7. Validate install, build, typecheck, every canonical QNT suite, private-file protection, and whitespace.
8. Create the PR, wait for CI, correct only demonstrated deployment-scope failures, and merge when green.
9. Verify the production URL from an external browser and HTTP client. Root must return 200 and render assets. Verify all critical routes and mobile/desktop views.
10. Do not claim success from Vercel `Ready` alone.

## Phase 2: Easy Start navigation

Only after production is HTTP 200:
1. Create `feat/easy-start-navigation` from updated main.
2. Port the intention of `02-navigation.patch`: expose `/how-to-install` in desktop, catalog, mobile, and footer navigation.
3. Use `How to install` in the existing `en-US` dictionary. Do not add a new locale in this ticket.
4. Add strict tests for all navigation surfaces and mobile close behavior.
5. Validate build, typecheck, all QNT suites, private-file protection, whitespace, and browser behavior.
6. Create PR and wait for CI. Do not merge this second PR without Javier/M365 Copilot review.

## Safety and scope

- No QNT-0016 plans/prices/purchases.
- PAYMENTS_ENABLED=false, DOWNLOADS_ENABLED=false, DEMO_MONITORING_ENABLED=false.
- No Supabase live writes or migrations.
- No invented data or deployment claims.
- Do not touch `feat/QNT-0015-product-plans-conversion`.
- Never include tokens or environment values in commits or reports.

## Review delivery

Create exactly one real ZIP renamed `.zip.txt` after Phase 2, containing the important modified files, full diff, validation output, PR/CI details, production HTTP verification, and real screenshots. Store it under `agent-deliveries/freebuff/` and push it on the navigation branch. Do not create additional delivery files.
