# Quantora review and change plan

## Critical finding

The repository is a full-stack TanStack Start application but its Vite configuration does not register Nitro. Current Vercel guidance for TanStack Start uses the Nitro Vite plugin so Vercel can detect and package SSR/server functions correctly. The existing custom Build Output API scripts may remain as a documented fallback, but Git-connected Vercel deployments should use the supported Nitro path first.

## Proposed implementation

### A. Production deployment repair

1. From updated `origin/main`, create `fix/vercel-production-deployment`.
2. Run `bun add -D nitro` so `package.json` and `bun.lock` are updated reproducibly.
3. Add `import { nitro } from "nitro/vite"` and `nitro()` to `vite.config.ts`.
4. Do not set a manual Output Directory in Vercel.
5. Clear obsolete dashboard overrides for build/output unless repository evidence requires them.
6. Use the repository root as Root Directory and `main` as Production Branch.
7. Run build, typecheck, all QNT tests, private-file guard, and `git diff --check`.
8. Open a PR, wait for CI, merge only if green, then verify the production alias and deployment URL with HTTP 200.
9. Verify `/`, `/strategies`, all four public strategy pages, `/how-to-install`, `/login`, `/register`, `/forgot-password`, and unauthenticated `/account` behavior.

### B. Navigation improvement

After production is healthy, use a separate branch `feat/easy-start-navigation`.
Add the existing `/how-to-install` route to:
- desktop primary navigation;
- catalog navigation;
- mobile navigation;
- product footer column.

Use the existing locale boundary and label `How to install` because the repository currently has only `en-US`. Do not invent a Spanish locale in this ticket.

### C. Workflow and Skill

Keep the repository workflow concise and cloud-aware. The Skill should recover context, verify Git/PR/CI, enforce product truth boundaries, update continuity, and create one `.zip.txt` review package only when files are needed.

## Product UX recommendations for later scoped tickets

- Remove public language that frames published strategies as pending review or unverified; keep provenance internal.
- Remove or disable simulated rent/buy prices before commercial launch.
- Make the public catalog clearly prioritize the four real strategies over mock fixtures.
- Keep backtest, demo monitoring, and real-account results objectively separated.
- Add a production status/commit endpoint or footer build marker only if it does not expose sensitive metadata.
- Add automated smoke checks for critical production routes after every main deployment.
- Add `robots.txt`, sitemap, canonical URL, Open Graph image, and structured metadata in a separate SEO ticket after the deployment is stable.
