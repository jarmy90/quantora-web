QUANTORA IMPROVEMENT BUNDLE
===========================
Purpose: hand this single package to Freebuff Cloud so it can implement, validate,
commit, push, open PRs, deploy, and verify the repaired site.

Priority order:
1. Restore Vercel production with the official TanStack Start + Nitro integration.
2. Verify production HTTP 200 and all critical routes.
3. Expose the existing /how-to-install route in desktop, mobile, and footer navigation.
4. Install the permanent Quantora workflow Skill.
5. Run all canonical checks and create reviewable PRs.

IMPORTANT
- Proposed files are candidates, not permission to overwrite newer repository work.
- Freebuff must compare each file against current origin/main and port only the intended changes.
- bun.lock must be updated by running `bun add -D nitro`, never hand-edited.
- No production success claim without opening the final URL and receiving HTTP 200.
- No QNT-0016 commercial work, payment activation, downloads, or Supabase live writes.
