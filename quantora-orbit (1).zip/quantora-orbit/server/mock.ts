import type { Telemetry } from "../lib/schema";
const names=["Stoch Adaptive","Modular Conductor","Sentiment Mirror","Quantora Sniper"];
export function mockTelemetry(t:number):Telemetry{
 const phase=t/8; const pnls=names.map((_,i)=>Math.sin(phase+i*1.7)*38 + Math.cos(phase*.37+i)*12);
 const floating=pnls.reduce((a,b)=>a+b,0); const now=new Date().toISOString();
 return {type:"telemetry",balance:1350+172+floating,initialBalance:1350,currency:"EUR",timestamp:now,
 bots:names.map((name,i)=>({id:`bot-${i+1}`,name,pnl:Number(pnls[i].toFixed(2)),exposurePct:[18,27,13,22][i],side:Math.abs(pnls[i])<4?"flat":i%2?"short":"long",updatedAt:now}))};
}