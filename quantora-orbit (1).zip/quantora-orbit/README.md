# Quantora Orbit

A cinematic, real-time 3D command center for four MetaTrader 5 Expert Advisors. The visual language is inspired by the density and living-matter feel of Gaploid's **Stardust**, while all shaders, React components and telemetry architecture in this repository are original.

## Highlights

- Four breathing, deforming shader entities driven by live PnL and exposure
- Positive/negative particle flow, color, elevation and motion semantics
- Bloom, vignette, film noise and restrained chromatic aberration
- Click/hover focus, Cinema camera tour and optional generative Web Audio
- Local “Moments” history when a bot crosses +€50 floating PnL
- Validated server-side telemetry, reconnecting browser WebSocket and mock mode
- Backend-only secrets. The browser never receives MT5 credentials
- Adaptive DPR and shader-based animation for responsive performance

> Add screenshots after first local run under `docs/screenshots/hero.png`. No fabricated screenshot is bundled.

## Architecture

```text
MT5 terminal / MetaApi / Manager API
        │ private authenticated bridge
        ▼
server.ts (Node + Next.js 15 + ws + Zod validation)
        │ /ws, normalized telemetry only
        ▼
WebSocketProvider → R3F Scene → BotSphere shaders + HUD
```

A persistent WebSocket requires a long-running Node process. This repository therefore uses a custom Next.js server and is suited to Docker, Railway, Render, Fly.io, a VM or Kubernetes. If the frontend is hosted on a serverless platform, deploy the WebSocket bridge separately and set `NEXT_PUBLIC_WS_URL` to its public `wss://` URL.

## Quick start

```bash
cp .env.example .env
npm install
npm run dev
```

Open `http://localhost:3000`. Mock telemetry is enabled by default.

## Connect real MT5 data

1. Run an MT5-side bridge you control, or use a provider such as MetaApi/Manager API.
2. Make that bridge emit exactly this normalized message:

```json
{
  "type": "telemetry",
  "balance": 1522.45,
  "initialBalance": 1350,
  "currency": "EUR",
  "timestamp": "2026-09-03T08:00:00.000Z",
  "bots": [
    {"id":"bot-1","name":"EA One","pnl":22.4,"exposurePct":18,"side":"long","updatedAt":"2026-09-03T08:00:00.000Z"},
    {"id":"bot-2","name":"EA Two","pnl":-8.2,"exposurePct":24,"side":"short","updatedAt":"2026-09-03T08:00:00.000Z"},
    {"id":"bot-3","name":"EA Three","pnl":0,"exposurePct":0,"side":"flat","updatedAt":"2026-09-03T08:00:00.000Z"},
    {"id":"bot-4","name":"EA Four","pnl":31.7,"exposurePct":16,"side":"long","updatedAt":"2026-09-03T08:00:00.000Z"}
  ]
}
```

3. Set `DATA_SOURCE=bridge`, `MT5_BRIDGE_WS_URL` and `MT5_BRIDGE_TOKEN` in `.env`.
4. Map MT5 positions to bots using magic number or comment in the bridge. Calculate exposure server-side with one documented definition, for example margin allocated divided by account equity.

## Security

- Never prefix secrets with `NEXT_PUBLIC_`.
- Never commit `.env`; it is ignored by Git.
- Use TLS (`wss://`) in production, a long random bridge token, origin restrictions and network allowlisting.
- Rotate any credential ever pasted into chat, screenshots, logs or Git history.
- Add authentication in front of this dashboard before exposing account telemetry publicly.
- Validate and rate-limit bridge input. The included Zod schema rejects malformed telemetry.

## Production

```bash
cp .env.example .env
# edit safe environment variables
npm ci
npm run typecheck
npm run build
npm start
```

Or:

```bash
docker compose up -d --build
```

Set the reverse proxy to support WebSocket upgrade headers and configure HTTPS. Health monitoring can check `/` and a synthetic WebSocket connection to `/ws`.

## Visual tuning

- Particle counts: `components/Scene.tsx` and `components/SphereBot.tsx`
- Shader deformation/color: `components/SphereBot.tsx`
- Post-processing: `components/Scene.tsx`
- Bot positions and camera: `components/Scene.tsx`
- Profit snapshot threshold: `components/WebSocketProvider.tsx`

## Notes

Physics is intentionally light: Rapier owns collision-ready bodies while animation stays kinematic and deterministic. For stronger attraction/repulsion, switch to dynamic rigid bodies and apply impulses in `useFrame`, then cap velocities to preserve the cinematic composition.

## Credits

Visual inspiration: Gaploid/stardust, MIT licensed. No source code or embedded planetary datasets from Stardust are copied here.

## License

MIT.
