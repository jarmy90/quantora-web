"use client";
import dynamic from "next/dynamic"; import { WebSocketProvider } from "@/components/WebSocketProvider"; import { HUD } from "@/components/HUD";
const Scene=dynamic(()=>import("@/components/Scene").then(m=>m.Scene),{ssr:false,loading:()=> <div className="loading">FORMANDO MATERIA...</div>});
export default function Home(){return <WebSocketProvider><main><Scene/><HUD/></main></WebSocketProvider>}