import type { Metadata } from "next"; import "./globals.css";
export const metadata:Metadata={title:"Quantora Orbit",description:"Cinematic real-time MT5 bot telemetry"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="es"><body>{children}</body></html>}