import { createServer } from "node:http";
import next from "next";
import { WebSocket, WebSocketServer } from "ws";
import { telemetrySchema, type Telemetry } from "./lib/schema";
import { mockTelemetry } from "./server/mock";

const dev = process.env.NODE_ENV !== "production";
const port = Number(process.env.PORT ?? 3000);
const app = next({ dev });
const handle = app.getRequestHandler();

await app.prepare();
const server = createServer((req, res) => handle(req, res));
const wss = new WebSocketServer({ noServer: true });
let latest: Telemetry = mockTelemetry(0);

function broadcast(data: Telemetry) {
  latest = data;
  const body = JSON.stringify(data);
  for (const client of wss.clients) if (client.readyState === WebSocket.OPEN) client.send(body);
}

wss.on("connection", (socket) => {
  socket.send(JSON.stringify(latest));
  const heartbeat = setInterval(() => socket.readyState === WebSocket.OPEN && socket.ping(), 25000);
  socket.on("close", () => clearInterval(heartbeat));
});

server.on("upgrade", (req, socket, head) => {
  if (req.url !== "/ws") return socket.destroy();
  const allowed = process.env.WS_ALLOWED_ORIGIN;
  if (allowed && req.headers.origin !== allowed) return socket.destroy();
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit("connection", ws, req));
});

if ((process.env.DATA_SOURCE ?? "mock") === "bridge") {
  const url = process.env.MT5_BRIDGE_WS_URL;
  if (!url) throw new Error("MT5_BRIDGE_WS_URL is required in bridge mode");
  const connect = () => {
    const upstream = new WebSocket(url, { headers: { Authorization: `Bearer ${process.env.MT5_BRIDGE_TOKEN ?? ""}` } });
    upstream.on("message", raw => {
      const parsed = telemetrySchema.safeParse(JSON.parse(raw.toString()));
      if (parsed.success) broadcast(parsed.data); else console.error("Rejected bridge payload", parsed.error.issues);
    });
    upstream.on("close", () => setTimeout(connect, 3000));
    upstream.on("error", err => console.error("Bridge error", err.message));
  };
  connect();
} else {
  let tick = 0;
  setInterval(() => broadcast(mockTelemetry(++tick)), 1000);
}
server.listen(port, () => console.log(`Quantora Orbit on http://localhost:${port}`));