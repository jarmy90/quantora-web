import { readFileSync } from 'node:fs';
const nav=readFileSync('src/components/Nav.tsx','utf8');
const footer=readFileSync('src/components/Footer.tsx','utf8');
const i18n=readFileSync('src/i18n/index.ts','utf8');
const vercel=JSON.parse(readFileSync('vercel.json','utf8')) as Record<string,unknown>;
const build=readFileSync('build-vercel.sh','utf8');
const checks:Array<[string,boolean]>=[
['install guide appears across navigation', (nav.match(/to=\"\/how-to-install\"/g)??[]).length>=3],
['install guide appears in footer',footer.includes('to="/how-to-install"')],
['leader marketplace positioning',i18n.includes('The EA marketplace built on evidence')],
['public score has no beta label',i18n.includes("'detail.scoreBeta': 'Quantora Score'")],
['published strategy replaces coming soon badge',i18n.includes("'detail.comingSoonBadge': 'Published strategy'")],
['Vercel invokes SSR output build',vercel.buildCommand==='bash ./build-vercel.sh'],
['frozen install configured',vercel.installCommand==='bun install --frozen-lockfile'],
['SSR build emits Build Output API',build.includes('.vercel/output/config.json')],
];let failed=0;for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'}: ${name}`);if(!ok)failed++;}console.log(`Product foundation: ${checks.length-failed}/${checks.length} passed`);if(failed)process.exit(1);
