# Quantora · Commercial Roadmap (QNT-0012)

Goal: a professional, transparent, conversion-oriented platform that a
beginner or intermediate trader understands in ~10 seconds, with a simple
commercial flow and a clear separation between **historical backtest**,
**demo monitoring** and **verified live results**. Each phase below builds on
the previous one; nothing is merged or deployed automatically.

---

## QNT-0012 · Foundation (this phase)

- **Prerequisites:** QNT-0011 (real strategies, product states) merged.
- **Data involved:** none persisted; contracts, safe catalog, env contract,
  preparatory migration (not applied). Identity contract: `id` (internal
  uuid) vs `product_id` (stable text, UNIQUE) vs `strategy_id`; internal FKs
  use `product_ref`. `customer.email`/`display_name` are nullable until
  QNT-0013 decides identity. Billing rule: `rental` →
  monthly/quarterly/annual; `purchase` → one_time (validated in TS,
  `canSelectPlan` and SQL CHECK).
- **Security boundary:** feature flags default false; no write endpoints;
  secrets never leave the server.
- **Definition of done:** domain contracts, state rules, safe catalog,
  `.env.example`, `src/config.ts`, migration SQL, repository interfaces,
  architecture + roadmap docs, automated tests, CI green, no capability
  enabled.
- **Remains disabled:** everything commercial.

## QNT-0013 · Authentication and session

**Status: implemented and live-verified.**

- **Prerequisites:** QNT-0012 contracts; `.env.example`; customers table.
- **Data involved:** customers, session state (Supabase Auth, HttpOnly cookie).
- **Security boundary:** Supabase Auth (email + password), server-side session
  verification via `getUser(token)`, HttpOnly/SameSite/Lax cookies, safe
  `returnTo` (internal paths only), service-role key never used.
- **Definition of done (code):** registration, login, logout, password reset
  request + new-password flow, email-verification callback, protected
  `/account`, auth↔customer relation migration (`0002`), `AUTH_NOT_CONFIGURED`
  state, tests + CI step. See `docs/AUTHENTICATION.md`.
- **Live verification record (no personal data):** the Quantora Supabase
  project is configured; migrations `0001` + `0002` applied via SQL Editor;
  email registration verified; email confirmation verified; login verified;
  protected `/account` verified; logout verified; password recovery verified;
  one owner-controlled test account exists; zero orders, payments, licenses,
  entitlements and downloads.
- **No longer pending:** creating the project, configuring variables, applying
  migrations, live auth verification.
- **Remains disabled:** purchases, payments, downloads, demo monitoring.

## QNT-0014 · Easy Start installation onboarding

- **Rationale:** installation onboarding ships BEFORE payments because it
  reduces fear and abandonment before the conversion moment — a beginner
  who understands “I can install this bot myself” is far more likely to
  buy or rent later.
- **Prerequisites:** QNT-0013 auth + live Supabase; four public strategies;
  `coming_soon` products.
- **Data involved:** none new; purely visual/educational (public route
  `/how-to-install`, reusable `EasyStartSteps` component).
- **Security boundary:** informational only — no downloads, no license
  fiction, no MT5 credentials, no real EA files, no private source.
- **Definition of done:** three-step public guide (Download → Install in
  MT5 → Test in demo), compact block on strategy details, home section,
  `/account` guide entry; demo-first messaging; responsive visuals;
  accessibility and SEO.
- **Remains disabled:** products, plans, payments, downloads, licenses,
  demo monitoring.

## QNT-0015 · Demo monitoring pilot

**Status: implemented (pilot, flag off).**

- **Prerequisites:** server functions infrastructure; safe product linkage.
- **Data involved:** demo-account monitoring records per strategy.
- **Security boundary:** demo data is separate from backtest and from
  verified live results; clearly labelled; no invented balances;
  `DEMO_MONITORING_ENABLED` defaults to false.
- **Definition of done:** a pilot module (labelled DEMO MONITORING) that
  distinguishes backtest / demo / verified live; connection state machine
  (`not_connected`, `connecting`, `live_demo`, `stale`, `offline`); domain
  contract + pilot source returning honest `not_connected` until real demo
  data is supplied; tests + CI step; see
  `docs/DEMO_MONITORING_ARCHITECTURE.md`.
- **Remains disabled:** checkout, payments, downloads, licenses, real MT5
  connection.

## QNT-0016 · Plans, purchase and rental

- **Prerequisites:** QNT-0013; plans table; pricing decisions.
- **Data involved:** plans (rental/purchase), orders (draft/pending_payment).
- **Security boundary:** `paid` set only server-side; price shown only from
  active plans; checkout cannot start for coming_soon/paused/deprecated.
- **Definition of done:** plan selection UI, order creation, checkout
  readiness gated by `canStartCheckout`, customer order history.
- **Remains disabled:** actual payment capture, downloads, licenses.

## QNT-0017 · Payment provider and webhooks

- **Prerequisites:** QNT-0016; provider decision (none chosen yet).
- **Data involved:** payments, provider webhooks.
- **Security boundary:** secret keys server-only; webhook signature
  verification; `providerReference` never exposed publicly.
- **Definition of done:** payment capture, webhook handling, order → paid
  transitions server-side, refund/cancel handling.
- **Remains disabled:** downloads, license activation (next phase).

## QNT-0018 · Licensing and protected delivery

- **Prerequisites:** QNT-0017; licenses + entitlements tables.
- **Data involved:** licenses, entitlements, protected files.
- **Security boundary:** download requires product `available` +
  `commercialDownloadEnabled` + license `active` + entitlement `granted`;
  final check server-side; private storage never in the bundle.
- **Definition of done:** license activation from paid orders, entitlement
  gating, protected EA delivery (EX5), activation limits if defined.
- **Remains disabled:** nothing listed here — the commercial flow is
  complete; monitoring continues to be separate.

---

## Visual goal (all phases)

Professional and modern; fast comprehension; simple purchase/rental flow;
transparency without exaggerated results; clear separation of backtest, demo
monitoring and verified live results. Demo/sample content never presented as
published product.

---

## Leadership roadmap · marketplace standard

This sequence evolves Quantora from a transparent strategy catalog into the reference marketplace for discovering, renting and buying MetaTrader 5 Expert Advisors. Public product language stays confident and simple; unavailable commercial actions remain technically gated until their implementation is complete.

### QNT-0016A · Marketplace product surface
- Make every published strategy immediately comparable by market, frequency, Profit Factor, drawdown, trade count and Quantora Score.
- Remove public development-state language such as beta, under review and coming soon while preserving internal provenance and feature gates.
- Introduce a clear access-interest CTA without inventing prices, availability or saved notifications.

### QNT-0016B · Comparison and decision workspace
- Allow users to compare up to three published strategies side by side.
- Explain Quantora Score through plain-language component summaries.
- Add suitability descriptors based only on existing factual data, never recommendations or invented risk profiles.

### QNT-0016C · Plans and pricing decision
- Define rental and purchase plans only after Javier approves prices, billing periods, update policy, activation limits and refunds.
- Prices must be server-resolved from active plans and never hard-coded in presentation components.

### QNT-0017 · Checkout and payment integrity
- Provider selection, server-created checkout, signed webhooks, idempotency and order history.
- No client can mark an order paid.

### QNT-0018 · Licensing and protected EA delivery
- Active license plus entitlement required for every download.
- EX5 and SET files remain outside the public repository and public bundle.
- Customer receives installation materials and version/update history.

### QNT-0019 · Customer success and activation
- Guided post-purchase setup, demo-first checklist, installation diagnostics and support entry point.
- Measure activation without collecting trading credentials.

### QNT-0020 · Evidence and monitoring leadership
- Demo monitoring when supplied data exists, always separate from backtest.
- Verified live results only through a separately implemented evidence boundary.

### QNT-0021 · Marketplace growth foundation
- SEO, sitemap, structured strategy metadata, share cards, analytics consent and conversion funnel measurement.
- No fabricated testimonials, rankings or popularity claims.

### QNT-0022 · Seller and strategy operations
- Controlled onboarding, evidence intake, version releases, commercial approval and quality monitoring.
- Publication remains gated by the common evidence filter and explicit editorial policy.

---

## Leadership roadmap · marketplace standard

This sequence turns Quantora into the reference marketplace for discovering, renting and buying MetaTrader 5 Expert Advisors. Public language remains confident and simple, while unavailable commercial actions stay technically gated until implemented.

### QNT-0016A · Marketplace product surface
- Make every published strategy directly comparable by market, frequency, Profit Factor, drawdown, trades and Quantora Score.
- Remove public development-state language while preserving internal provenance and feature gates.
- Introduce a clear access-interest CTA without inventing prices, availability or saved notifications.

### QNT-0016B · Comparison and decision workspace
- Compare up to three published strategies side by side.
- Explain Quantora Score with plain-language component summaries.
- Derive descriptors only from factual strategy data, never recommendations.

### QNT-0016C · Plans and pricing decision
- Define rental and purchase plans after explicit approval of prices, billing, updates, activation limits and refunds.
- Resolve prices server-side from active plans, never hard-code pricing in presentation components.

### QNT-0017 · Checkout and payment integrity
- Server-created checkout, signed webhooks, idempotency and order history.
- No client may mark an order paid.

### QNT-0018 · Licensing and protected delivery
- Require an active license and entitlement for every download.
- Keep EX5 and SET outside the public repository and bundle.

### QNT-0019 · Customer activation
- Guided post-purchase setup, demo-first checklist, diagnostics and support.

### QNT-0020 · Evidence and monitoring leadership
- Demo monitoring only when supplied data exists and always separate from backtest.
- Verified live results only through a separate evidence boundary.

### QNT-0021 · Marketplace growth foundation
- SEO, sitemap, structured strategy metadata, share cards, consent-aware analytics and funnel measurement.

### QNT-0022 · Seller and strategy operations
- Controlled seller onboarding, evidence intake, releases, commercial approval and quality monitoring.
