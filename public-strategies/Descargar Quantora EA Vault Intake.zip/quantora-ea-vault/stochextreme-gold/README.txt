STOCHEXTREME GOLD

Estado: EA probado por el propietario.
Mercado previsto: oro, usando el simbolo de oro disponible en IC Markets.
Motor: Stochastic adaptativo, confirmacion de 60 segundos, salida MFE-Giveback y salida estructural al extremo contrario.
Requiere cuenta HEDGING para mantener solapamiento independiente BUY/SELL.

Instalacion interna:
1. Copiar el MQ5 a MQL5/Experts/Quantora/.
2. Compilar en MetaEditor.
3. Cargar el SET.
4. Revisar el nombre concreto del simbolo y el offset del servidor.

No publicar el codigo fuente ni el EX5 en la web publica.
