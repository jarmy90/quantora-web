FIRST TRIANGLE USTEC M30

Estado: EA probado por el propietario.
Simbolo previsto: USTEC/NQ en M30.
Salida principal: MFE-Giveback adaptativo. Salida de respaldo: triangulo contrario.

Instalacion interna:
1. Copiar el MQ5 a MQL5/Experts/Quantora/.
2. Compilar en MetaEditor.
3. Cargar el SET.
4. Confirmar simbolo, volumen, magic y permisos.

No publicar el codigo fuente ni el EX5 en la web publica.
