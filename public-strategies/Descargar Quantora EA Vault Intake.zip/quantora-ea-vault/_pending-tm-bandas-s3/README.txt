TM BANDAS S3 - PENDIENTE DE VINCULAR EA

Este SET recoge la configuracion del backtest KEEPER_SL12_TP36.
El archivo EA de TM Bandas S3 no estaba incluido en el ZIP de cuatro EAs recibido.
Freebuff debe almacenar esta carpeta como pending y NO declarar el SET como instalable hasta que Javier aporte el MQ5/EX5 correspondiente y se comprueben los nombres exactos de sus inputs.
No modificar ni adaptar otro EA para rellenar esta ausencia.
