PAQUETE MAESTRO DE EAs QUANTORA

Objetivo: entregar a Freebuff una estructura inicial para organizar el almacenamiento privado de EAs y preparar su futura conexion con productos Quantora.

Cada EA listo contiene:
- MQ5 fuente recibido
- SET de sus valores actuales por defecto
- VERSION.txt
- SHA256.txt
- README.txt

Freebuff debe revisar nombres, generar inventario de repositorio, mantener una carpeta por producto y no exponer el codigo ni binarios en el bundle publico.
El EA de TM Bandas S3 no estaba en la entrega. Su SET se conserva como pendiente y no debe marcarse como instalable.
