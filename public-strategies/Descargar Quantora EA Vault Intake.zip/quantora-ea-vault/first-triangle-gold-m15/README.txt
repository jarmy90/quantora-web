FIRST TRIANGLE GOLD M15

Estado: EA probado por el propietario. Pendiente de la revision final ORO16 indicada por Javier.
Simbolo previsto: XAUUSD/GOLD en IC Markets.
Timeframe: M15.
Configuracion fijada por el propio EA: volumen 0.02, SL 55, trailing activacion 60 y distancia 25.

Instalacion interna:
1. Copiar el MQ5 a MQL5/Experts/Quantora/.
2. Compilar en MetaEditor.
3. Cargar el SET en las propiedades del EA.
4. Confirmar simbolo, permisos y cuenta antes de activar Algo Trading.

No publicar el codigo fuente ni el EX5 en la web publica. Conservarlo en almacenamiento privado del producto.
