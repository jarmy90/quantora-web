//+------------------------------------------------------------------+
//| Quantora_FirstTriangle_Gold_M15_FINAL_v1_02.mq5                   |
//| Real execution EA: tested M15 / SL55 / trailing 60-25            |
//| Exact First Triangle signal engine copied from supplied EA.       |
//+------------------------------------------------------------------+
#property copyright "Quantora"
#property version   "1.02"
#property strict

input group "IC Markets execution"
input double          InpVolume             = 0.02;
input ulong           InpMagic              = 26081755;
input int             InpDeviationPoints    = 30;
input double          InpMarginReserveEUR   = 100.0; // minimum free margin kept after opening
input bool            InpAllowLong          = true;
input bool            InpAllowShort         = true;
input bool            InpCloseOnOpposite    = true;

input group "Validated First Triangle configuration"
input ENUM_TIMEFRAMES InpSignalTF           = PERIOD_M15;
input double          InpStopPriceDistance  = 55.0;
input double          InpTrailActivation    = 60.0;
input double          InpTrailDistance      = 25.0;

input group "Signal engine - tested values"
input int             InpWarmupBars         = 350;
input int             InpCloudPeriod        = 52;
input int             InpCloudSmooth        = 10;
input int             InpATRPeriod          = 10;
input double          InpATRMultiplier      = 3.0;
input int             InpRSIPeriod1         = 6;
input int             InpRSISmooth1         = 5;
input double          InpQQEFactor1         = 3.0;
input int             InpBBLength           = 50;
input double          InpBBMultiplier       = 0.35;
input int             InpRSIPeriod2         = 6;
input int             InpRSISmooth2         = 5;
input double          InpQQEFactor2         = 1.61;
input double          InpQQEThreshold2      = 3.0;

input group "Display"
input bool            InpShowComment        = true;

#define MAX_CALC_BARS 700
#define TF_COUNT 1
#define SL_COUNT 5
#define EXIT_COUNT 9
#define SESSION_COUNT 6
#define VAR_COUNT 270

struct IndicatorState
  {
   datetime bar_time;
   double open,high,low,close;
   double atr;
   bool cloud_bull;
   int st_dir;
   double st_line;
   bool qqe_blue;
   bool qqe_red;
   bool full_long;
   bool full_short;
  };

//-------------------------- Utilities --------------------------------
string B(bool v){ return v ? "true" : "false"; }
string D(int d){ return d>0 ? "BUY" : d<0 ? "SELL" : "NONE"; }
double TickSize()
  {
   double x=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   return x>0 ? x : SymbolInfoDouble(_Symbol,SYMBOL_POINT);
  }
double NormTick(double p)
  {
   double t=TickSize();
   return NormalizeDouble(MathRound(p/t)*t,(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS));
  }
//---------------------- Math / series helpers ------------------------
double SMA(const double &a[],int i,int n)
  {
   if(i<n-1) return EMPTY_VALUE;
   double s=0; for(int k=i-n+1;k<=i;k++) s+=a[k];
   return s/n;
  }
double VWMA(const double &src[],const long &vol[],int i,int n)
  {
   if(i<n-1) return EMPTY_VALUE;
   double sv=0,sw=0;
   for(int k=i-n+1;k<=i;k++){ double w=(double)MathMax((long)1,vol[k]); sv+=src[k]*w; sw+=w; }
   return sw>0 ? sv/sw : EMPTY_VALUE;
  }
double StDevPopulation(const double &a[],int i,int n)
  {
   if(i<n-1) return EMPTY_VALUE;
   double mean=0; for(int k=i-n+1;k<=i;k++) mean+=a[k]; mean/=n;
   double ss=0; for(int k=i-n+1;k<=i;k++){ double d=a[k]-mean; ss+=d*d; }
   return MathSqrt(ss/n);
  }
void EMA(const double &src[],double &out[],int n,int total)
  {
   double alpha=2.0/(n+1.0); out[0]=src[0];
   for(int i=1;i<total;i++) out[i]=alpha*src[i]+(1.0-alpha)*out[i-1];
  }
void RMA(const double &src[],double &out[],int n,int total)
  {
   out[0]=src[0];
   for(int i=1;i<total;i++) out[i]=(out[i-1]*(n-1)+src[i])/n;
  }
void RSI(const double &close[],double &out[],int n,int total)
  {
   double up[],dn[],au[],ad[];
   ArrayResize(up,total); ArrayResize(dn,total); ArrayResize(au,total); ArrayResize(ad,total);
   up[0]=0;dn[0]=0;
   for(int i=1;i<total;i++)
     { double ch=close[i]-close[i-1]; up[i]=MathMax(ch,0.0); dn[i]=MathMax(-ch,0.0); }
   RMA(up,au,n,total); RMA(dn,ad,n,total);
   for(int i=0;i<total;i++)
     {
      if(ad[i]<=1e-12) out[i]=au[i]<=1e-12 ? 50.0 : 100.0;
      else { double rs=au[i]/ad[i]; out[i]=100.0-100.0/(1.0+rs); }
     }
  }
bool CrossAny(double a_prev,double a_now,double b_prev,double b_now)
  { return (a_prev<=b_prev && a_now>b_now) || (a_prev>=b_prev && a_now<b_now); }

//--------------------- Indicator reconstruction (unchanged signal engine) ----------------------
bool CalculateClosedStateTF(ENUM_TIMEFRAMES tf,IndicatorState &out,IndicatorState &prev_out)
  {
   int request=MAX_CALC_BARS;
   MqlRates rr[]; ArraySetAsSeries(rr,true);
   int copied=CopyRates(_Symbol,tf,1,request,rr);
   int min_need=MathMax(InpCloudPeriod+InpCloudSmooth+50,250);
   if(copied<min_need) return false;

   int n=copied;
   double o[],h[],l[],c[],tr[],atr[]; long vol[]; datetime tm[];
   ArrayResize(o,n);ArrayResize(h,n);ArrayResize(l,n);ArrayResize(c,n);
   ArrayResize(tr,n);ArrayResize(atr,n);ArrayResize(vol,n);ArrayResize(tm,n);
   for(int i=0;i<n;i++)
     {
      int z=n-1-i; o[i]=rr[z].open;h[i]=rr[z].high;l[i]=rr[z].low;c[i]=rr[z].close;
      vol[i]=rr[z].tick_volume;tm[i]=rr[z].time;
      double pc=i>0?c[i-1]:c[i];
      tr[i]=MathMax(h[i]-l[i],MathMax(MathAbs(h[i]-pc),MathAbs(l[i]-pc)));
     }
   RMA(tr,atr,InpATRPeriod,n);

   double haC[],haO[],haC1[],haO1[],haCs[],haOs[];
   ArrayResize(haC,n);ArrayResize(haO,n);ArrayResize(haC1,n);ArrayResize(haO1,n);
   ArrayResize(haCs,n);ArrayResize(haOs,n);
   for(int i=0;i<n;i++)
     {
      haC[i]=(o[i]+h[i]+l[i]+c[i])/4.0;
      haO[i]=i==0 ? (o[i]+c[i])/2.0 : (haO[i-1]+haC[i-1])/2.0;
      haC1[i]=VWMA(haC,vol,i,InpCloudPeriod);
      haO1[i]=VWMA(haO,vol,i,InpCloudPeriod);
      if(haC1[i]==EMPTY_VALUE) haC1[i]=haC[i];
      if(haO1[i]==EMPTY_VALUE) haO1[i]=haO[i];
      haCs[i]=VWMA(haC1,vol,i,InpCloudSmooth);
      haOs[i]=VWMA(haO1,vol,i,InpCloudSmooth);
      if(haCs[i]==EMPTY_VALUE) haCs[i]=haC1[i];
      if(haOs[i]==EMPTY_VALUE) haOs[i]=haO1[i];
     }

   double up[],dn[]; int st[];
   ArrayResize(up,n);ArrayResize(dn,n);ArrayResize(st,n);
   for(int i=0;i<n;i++)
     {
      double src=(h[i]+l[i])/2.0;
      double rawUp=src-InpATRMultiplier*atr[i];
      double rawDn=src+InpATRMultiplier*atr[i];
      if(i==0){ up[i]=rawUp;dn[i]=rawDn;st[i]=1; }
      else
        {
         up[i]=(c[i-1]>up[i-1]) ? MathMax(rawUp,up[i-1]) : rawUp;
         dn[i]=(c[i-1]<dn[i-1]) ? MathMin(rawDn,dn[i-1]) : rawDn;
         st[i]=st[i-1];
         if(st[i-1]==-1 && c[i]>dn[i-1]) st[i]=1;
         else if(st[i-1]==1 && c[i]<up[i-1]) st[i]=-1;
        }
     }

   double rsi1[],rsi2[],rma1[],rma2[];
   ArrayResize(rsi1,n);ArrayResize(rsi2,n);ArrayResize(rma1,n);ArrayResize(rma2,n);
   RSI(c,rsi1,InpRSIPeriod1,n); RSI(c,rsi2,InpRSIPeriod2,n);
   EMA(rsi1,rma1,InpRSISmooth1,n); EMA(rsi2,rma2,InpRSISmooth2,n);

   double abs1[],maAbs1[],maAbs12[],dar1[],lb1[],sb1[],fast1[],center1[];
   double abs2[],maAbs2[],maAbs22[],dar2[],lb2[],sb2[],fast2[];
   int qtrend1[],qtrend2[];
   ArrayResize(abs1,n);ArrayResize(maAbs1,n);ArrayResize(maAbs12,n);ArrayResize(dar1,n);
   ArrayResize(lb1,n);ArrayResize(sb1,n);ArrayResize(fast1,n);ArrayResize(center1,n);ArrayResize(qtrend1,n);
   ArrayResize(abs2,n);ArrayResize(maAbs2,n);ArrayResize(maAbs22,n);ArrayResize(dar2,n);
   ArrayResize(lb2,n);ArrayResize(sb2,n);ArrayResize(fast2,n);ArrayResize(qtrend2,n);
   abs1[0]=0;abs2[0]=0;
   for(int i=1;i<n;i++){abs1[i]=MathAbs(rma1[i]-rma1[i-1]);abs2[i]=MathAbs(rma2[i]-rma2[i-1]);}
   EMA(abs1,maAbs1,InpRSIPeriod1*2-1,n); EMA(maAbs1,maAbs12,InpRSIPeriod1*2-1,n);
   EMA(abs2,maAbs2,InpRSIPeriod2*2-1,n); EMA(maAbs2,maAbs22,InpRSIPeriod2*2-1,n);
   for(int i=0;i<n;i++){dar1[i]=maAbs12[i]*InpQQEFactor1;dar2[i]=maAbs22[i]*InpQQEFactor2;}

   for(int i=0;i<n;i++)
     {
      double nlb1=rma1[i]-dar1[i],nsb1=rma1[i]+dar1[i];
      double nlb2=rma2[i]-dar2[i],nsb2=rma2[i]+dar2[i];
      if(i==0)
        { lb1[i]=nlb1;sb1[i]=nsb1;qtrend1[i]=1;lb2[i]=nlb2;sb2[i]=nsb2;qtrend2[i]=1; }
      else
        {
         lb1[i]=(rma1[i-1]>lb1[i-1] && rma1[i]>lb1[i-1])?MathMax(lb1[i-1],nlb1):nlb1;
         sb1[i]=(rma1[i-1]<sb1[i-1] && rma1[i]<sb1[i-1])?MathMin(sb1[i-1],nsb1):nsb1;
         bool crossShort1=CrossAny(rma1[i-1],rma1[i],i>1?sb1[i-2]:sb1[i-1],sb1[i-1]);
         bool crossLong1 =CrossAny(i>1?lb1[i-2]:lb1[i-1],lb1[i-1],rma1[i-1],rma1[i]);
         qtrend1[i]=crossShort1?1:crossLong1?-1:qtrend1[i-1];

         lb2[i]=(rma2[i-1]>lb2[i-1] && rma2[i]>lb2[i-1])?MathMax(lb2[i-1],nlb2):nlb2;
         sb2[i]=(rma2[i-1]<sb2[i-1] && rma2[i]<sb2[i-1])?MathMin(sb2[i-1],nsb2):nsb2;
         bool crossShort2=CrossAny(rma2[i-1],rma2[i],i>1?sb2[i-2]:sb2[i-1],sb2[i-1]);
         bool crossLong2 =CrossAny(i>1?lb2[i-2]:lb2[i-1],lb2[i-1],rma2[i-1],rma2[i]);
         qtrend2[i]=crossShort2?1:crossLong2?-1:qtrend2[i-1];
        }
      fast1[i]=(qtrend1[i]==1?lb1[i]:sb1[i]);
      fast2[i]=(qtrend2[i]==1?lb2[i]:sb2[i]);
      center1[i]=fast1[i]-50.0;
     }

   int ix=n-1,ip=n-2;
   double basis=SMA(center1,ix,InpBBLength);
   double dev=InpBBMultiplier*StDevPopulation(center1,ix,InpBBLength);
   double upper=basis+dev,lower=basis-dev;
   bool blue=(rma2[ix]-50.0>InpQQEThreshold2) && (rma1[ix]-50.0>upper);
   bool red =(rma2[ix]-50.0<-InpQQEThreshold2) && (rma1[ix]-50.0<lower);

   double basisP=SMA(center1,ip,InpBBLength);
   double devP=InpBBMultiplier*StDevPopulation(center1,ip,InpBBLength);
   bool blueP=(rma2[ip]-50.0>InpQQEThreshold2) && (rma1[ip]-50.0>basisP+devP);
   bool redP =(rma2[ip]-50.0<-InpQQEThreshold2) && (rma1[ip]-50.0<basisP-devP);

   out.bar_time=tm[ix];out.open=o[ix];out.high=h[ix];out.low=l[ix];out.close=c[ix];out.atr=atr[ix];
   out.cloud_bull=haCs[ix]>=haOs[ix];out.st_dir=st[ix];out.st_line=st[ix]==1?up[ix]:dn[ix];
   out.qqe_blue=blue;out.qqe_red=red;
   out.full_long=out.cloud_bull && out.st_dir==1 && blue;
   out.full_short=!out.cloud_bull && out.st_dir==-1 && red;

   prev_out.bar_time=tm[ip];prev_out.open=o[ip];prev_out.high=h[ip];prev_out.low=l[ip];prev_out.close=c[ip];prev_out.atr=atr[ip];
   prev_out.cloud_bull=haCs[ip]>=haOs[ip];prev_out.st_dir=st[ip];prev_out.st_line=st[ip]==1?up[ip]:dn[ip];
   prev_out.qqe_blue=blueP;prev_out.qqe_red=redP;
   prev_out.full_long=prev_out.cloud_bull && prev_out.st_dir==1 && blueP;
   prev_out.full_short=!prev_out.cloud_bull && prev_out.st_dir==-1 && redP;
   return true;
  }




#include <Trade/Trade.mqh>
CTrade g_trade;
datetime g_last_bar=0;
int g_bars_seen=0;
int g_cycle_side=0;
string g_cycle_key="";

void SaveCycleSide()
  {
   if(g_cycle_key!="")GlobalVariableSet(g_cycle_key,(double)g_cycle_side);
  }

void SetCycleSide(int side)
  {
   g_cycle_side=side;
   SaveCycleSide();
  }

double NormalizeVolume(double requested)
  {
   double vmin=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double vmax=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(step<=0.0)step=0.01;
   double v=MathMax(vmin,MathMin(vmax,requested));
   v=MathFloor(v/step+1e-9)*step;
   int digits=0;double x=step;while(digits<8 && MathAbs(x-MathRound(x))>1e-9){x*=10.0;digits++;}
   return NormalizeDouble(v,digits);
  }

bool IsGoldSymbol()
  {
   string s=_Symbol;StringToUpper(s);
   return StringFind(s,"XAU")>=0 || StringFind(s,"GOLD")>=0;
  }

bool FindOwnPosition(ulong &ticket,long &type,double &open_price,double &sl)
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong t=PositionGetTicket(i);if(t==0)continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol)continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=InpMagic)continue;
      ticket=t;type=PositionGetInteger(POSITION_TYPE);
      open_price=PositionGetDouble(POSITION_PRICE_OPEN);sl=PositionGetDouble(POSITION_SL);
      return true;
     }
   ticket=0;type=-1;open_price=0;sl=0;return false;
  }

bool TradeResultOK(string action)
  {
   uint r=g_trade.ResultRetcode();
   bool ok=(r==TRADE_RETCODE_DONE || r==TRADE_RETCODE_DONE_PARTIAL || r==TRADE_RETCODE_PLACED);
   if(!ok)Print(action," failed. retcode=",r," description=",g_trade.ResultRetcodeDescription());
   return ok;
  }

bool CloseOwnPosition(string reason)
  {
   ulong ticket;long type;double op,sl;if(!FindOwnPosition(ticket,type,op,sl))return true;
   ResetLastError();bool sent=g_trade.PositionClose(ticket,InpDeviationPoints);
   if(!sent || !TradeResultOK("PositionClose"))return false;
   Print("CLOSE ",reason," ticket=",ticket);
   return true;
  }

bool OpenPosition(int dir)
  {
   MqlTick q;if(!SymbolInfoTick(_Symbol,q))return false;
   double price=(dir>0?q.ask:q.bid);
   double sl=NormTick(dir>0?price-InpStopPriceDistance:price+InpStopPriceDistance);
   ResetLastError();
   double volume=NormalizeVolume(InpVolume);
   if(volume<=0.0){Print("OPEN_NOT_ATTEMPTED INVALID_VOLUME requested=",InpVolume);return false;}

   // Margin pre-check: no strategy change, only prevents blind broker rejection.
   double required_margin=0.0;
   ENUM_ORDER_TYPE order_type=(dir>0?ORDER_TYPE_BUY:ORDER_TYPE_SELL);
   if(!OrderCalcMargin(order_type,_Symbol,volume,price,required_margin))
     {
      Print("OPEN_NOT_ATTEMPTED MARGIN_CALC_FAILED error=",GetLastError(),
            " volume=",DoubleToString(volume,2)," price=",DoubleToString(price,_Digits));
      return false;
     }
   double free_margin=AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double after_margin=free_margin-required_margin;
   if(after_margin<InpMarginReserveEUR)
     {
      Print("OPEN_NOT_ATTEMPTED INSUFFICIENT_MARGIN volume=",DoubleToString(volume,2),
            " free=",DoubleToString(free_margin,2),
            " required=",DoubleToString(required_margin,2),
            " after=",DoubleToString(after_margin,2),
            " reserve=",DoubleToString(InpMarginReserveEUR,2));
      return false;
     }

   bool sent=(dir>0 ? g_trade.Buy(volume,_Symbol,0.0,sl,0.0,"FirstTriangle GOLD M15 SL55 ACT60 DIST25")
                    : g_trade.Sell(volume,_Symbol,0.0,sl,0.0,"FirstTriangle GOLD M15 SL55 ACT60 DIST25"));
   if(!sent || !TradeResultOK(dir>0?"Buy":"Sell"))return false;
   Print("OPEN ",(dir>0?"BUY":"SELL")," volume=",DoubleToString(volume,2)," initialSL=",DoubleToString(sl,_Digits));
   return true;
  }

void ManageTrailing()
  {
   ulong ticket;long type;double entry,old_sl;if(!FindOwnPosition(ticket,type,entry,old_sl))return;
   MqlTick q;if(!SymbolInfoTick(_Symbol,q))return;
   bool buy=(type==POSITION_TYPE_BUY);double mark=buy?q.bid:q.ask;
   double mfe=buy?mark-entry:entry-mark;if(mfe<InpTrailActivation)return;
   double candidate=NormTick(buy?mark-InpTrailDistance:mark+InpTrailDistance);
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   bool improve=buy?(old_sl==0.0 || candidate>old_sl+point*0.5):(old_sl==0.0 || candidate<old_sl-point*0.5);
   if(!improve)return;
   ResetLastError();bool sent=g_trade.PositionModify(ticket,candidate,0.0);
   if(!sent || !TradeResultOK("PositionModify"))return;
  }

void ProcessClosedBarSignal(const IndicatorState &s,const IndicatorState &p)
  {
   bool bt=InpAllowLong && s.full_long && !p.full_long;
   bool st=InpAllowShort && s.full_short && !p.full_short;
   int dir=bt?1:st?-1:0;if(dir==0)return;
   if(dir==g_cycle_side)
     {
      Print("SIGNAL BLOCKED BY ALTERNATION: ",(dir>0?"BUY":"SELL"),
            " | waiting for opposite First Triangle signal");
      return;
     }

   ulong ticket;long type;double op,sl;bool active=FindOwnPosition(ticket,type,op,sl);
   if(active)
     {
      int current=(type==POSITION_TYPE_BUY?1:-1);
      if(current!=dir && InpCloseOnOpposite)
        {
         if(!CloseOwnPosition("OPPOSITE_TRIANGLE_FALLBACK"))return;
         // Exact explorer behavior: opposite signal closes; it does not reverse on the same event.
        }
      SetCycleSide(dir);
      return;
     }
   if(OpenPosition(dir))SetCycleSide(dir);
  }

int OnInit()
  {
   if(InpSignalTF!=PERIOD_M15 || MathAbs(InpVolume-0.02)>1e-9 ||
      MathAbs(InpStopPriceDistance-55.0)>1e-9 ||
      MathAbs(InpTrailActivation-60.0)>1e-9 ||
      MathAbs(InpTrailDistance-25.0)>1e-9)
     {
      Print("QUANTORA ABORT: final Gold configuration must be M15, volume 0.02, SL55, ACT60, DIST25");
      return INIT_PARAMETERS_INCORRECT;
     }
   Print("FIRST TRIANGLE GOLD FINAL v1.02 | TF=M15 | VOL=0.02 | SL=55 | TRAIL_ACT=60 | TRAIL_DIST=25");
   if(!IsGoldSymbol())
     {
      Print("ERROR: attach this EA only to IC Markets XAUUSD/GOLD symbol. Current symbol=",_Symbol);
      return INIT_FAILED;
     }
   if(InpVolume<=0 || InpStopPriceDistance<=0 || InpTrailActivation<=0 || InpTrailDistance<=0)return INIT_PARAMETERS_INCORRECT;
   g_trade.SetExpertMagicNumber(InpMagic);
   g_trade.SetDeviationInPoints(InpDeviationPoints);
   g_trade.SetTypeFillingBySymbol(_Symbol);
   g_cycle_key="Quantora.FTGold.Cycle."+IntegerToString((int)AccountInfoInteger(ACCOUNT_LOGIN))+"."+_Symbol+"."+IntegerToString((int)InpMagic);
   if(GlobalVariableCheck(g_cycle_key))g_cycle_side=(int)GlobalVariableGet(g_cycle_key);
   ulong rt;long rtype;double rop,rsl;
   if(FindOwnPosition(rt,rtype,rop,rsl))
     {
      int broker_side=(rtype==POSITION_TYPE_BUY?1:-1);
      if(g_cycle_side==0)SetCycleSide(broker_side);
      Print("STATE RECONCILED: broker position ticket=",rt," side=",(broker_side>0?"BUY":"SELL")," cycle=",g_cycle_side);
     }
   else Print("STATE RESTORED: flat | cycle=",g_cycle_side);
   Print("FIRST TRIANGLE GOLD IC MARKETS READY | TF=M15 SL=55 activation=60 trail=25 | symbol=",_Symbol);
   return INIT_SUCCEEDED;
  }

void OnTick()
  {
   ManageTrailing();
   datetime bar=iTime(_Symbol,InpSignalTF,0);if(bar==0 || bar==g_last_bar)return;
   g_last_bar=bar;g_bars_seen++;
   IndicatorState s,p;if(!CalculateClosedStateTF(InpSignalTF,s,p))return;
   if(g_bars_seen<=1)return;
   ProcessClosedBarSignal(s,p);
   if(InpShowComment)
     {
      ulong ticket;long type;double op,sl;bool active=FindOwnPosition(ticket,type,op,sl);
      Comment("FIRST TRIANGLE GOLD - IC MARKETS",
              "\nSignal TF: M15 | SL: 55 | Trail: 60 / 25",
              "\nSymbol: ",_Symbol," | Magic: ",InpMagic,
              "\nPosition: ",(active?(type==POSITION_TYPE_BUY?"BUY":"SELL"):"FLAT"),
              "\nServer: ",TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS));
     }
  }

void OnDeinit(const int reason){SaveCycleSide();Comment("");}
//+------------------------------------------------------------------+
