//+------------------------------------------------------------------+
//|  TM_BANDAS_DUAL_AMP_KEEPER_v261.mq5  —  AMP Global / MNQ         |
//|                                                                  |
//|  KEEPER (22 jun 2026). SOLO opera la MAÑANA (S3 reversion).      |
//|  Escalera OFF (la martingala no crea edge: mismo PF, 3x DD).     |
//|  Edge en el FILTRO DE ENTRADA, validado 6/6 trimestres.          |
//|                                                                  |
//|  CONFIG:                                                         |
//|   * Carriles = SMA(7) de MAXIMOS y de MINIMOS en M3 REAL.        |
//|   * Senal S3: VENDE al volver al carril superior.                |
//|   * ENTRADA POR TICK al tocar el carril (InpConfirmM1_M=false):  |
//|     PARIDAD con el backtest MARTI, que entraba por tick. Con     |
//|     confirmacion M1 el fill era ~media banda peor (divergencia). |
//|   * Ventana MANANA: 06:00-14:00 UTC FIJO (AMP srv=UTC, sin DST). |
//|   * NY apertura: DESACTIVADA (InpUseSession=false).              |
//|   * SL 12 / TP 36 (1:3 validado, load-bearing).                  |
//|   * GATE: ATR(M3) en [15,21]  Y  railGap (ancho canal=up-lo)>=16.|
//|   * Lote FIJO 1 contrato MNQ. UNA entrada por senal (sin marti). |
//|   * Cierre seguro antes de 17:00 ET. Blindaje anti-doble v4.     |
//+------------------------------------------------------------------+
#property copyright "TM"
#property version   "2.61"
//  v2.61 KEEPER (22 jun): entrada por TICK (InpConfirmM1_M=false) = paridad backtest. BACKTESTEAR antes de real.
//  v2.60 KEEPER (20 jun): escalera OFF, SL12/TP36, gate ATR[15,21] & railGap>=16, solo manana.
#property strict

#include <Trade/Trade.mqh>
CTrade trade;

enum ScenDir { DIR_OFF=0, DIR_BUY=1, DIR_SELL=2 };
enum SLMode  { SL_FIXED=0, SL_OPPOSITE_RAIL=1 };
enum Zone    { Z_NONE=-1, Z_BELOW=0, Z_INSIDE=1, Z_ABOVE=2 };

input group "=== Carriles (SMA sobre M3 REAL) ==="
input int    InpRailPeriod = 7;
input int    InpRailShift   = 1;

input group "=== Direccion por escenario ==="
input ScenDir InpDir_InsideToUpper = DIR_OFF;  // S1
input ScenDir InpDir_InsideToLower = DIR_OFF;  // S2
input ScenDir InpDir_AboveToUpper  = DIR_SELL; // S3  <-- activo
input ScenDir InpDir_BelowToLower  = DIR_OFF;  // S4

input group "=== Salida ==="
input SLMode InpSLMode      = SL_FIXED;
input double InpSLPoints     = 14.0;   // [NY] stop fijo en puntos
input double InpTrailPoints  = 5.0;    // [NY] distancia trailing
input double InpTrailStart   = 30.0;   // [NY] activar trailing a +N pts
input double InpMaxTP        = 0.0;    // (sin uso; NY usa trailing)
input double InpSL_M         = 12.0;   // [MAÑANA] stop base — KEEPER 12 (1:3 validado)
input double InpTP_M         = 36.0;   // [MAÑANA] take-profit base — KEEPER 36 (1:3 validado, load-bearing)
input bool   InpConfirmM1_M  = false;  // KEEPER false = ENTRADA POR TICK al tocar carril (paridad backtest). true = espera cierre M1 (fill peor)
input double InpATRMin_M     = 15.0;   // [MAÑANA] ATR(M3) minimo — KEEPER 15 (banda validada 15-21; max via InpATRMax)
input double InpMinRailGap_M = 16.0;   // [MAÑANA] railGap minimo = ancho canal M3 (up-lo) — KEEPER 16 (6/6 trim; plato 16-18)

input group "=== Velocidad (medir) ==="
input int    InpVelLookbackBars = 3;
input int    InpVelFilterMode   = 0;
input double InpVelMin           = 0.0;
input double InpVelMax           = 999.0;

input group "=== Variables / Filtro ATR ==="
input int    InpATRPeriod   = 14;
input int    InpSlopeBarsM3 = 3;
input double InpATRMax       = 21.0;   // no operar si ATR(M3) > este valor (optimizado)

input group "=== Sesion 1 (srv IC = ET+7, FIJA) — apertura NY ==="
input bool   InpUseSession = false;    // DESACTIVADA: solo opera la MAÑANA
input int    InpHourStart  = 9;        // 09:30 ET (AMP srv=UTC: +5 inv / +4 ver, anclado US-DST)
input int    InpMinStart   = 30;
input int    InpHourEnd     = 11;      // 11:30 ET
input int    InpMinEnd      = 30;

input group "=== Sesion 2 (anclada UTC) — MAÑANA scalp ==="
input bool   InpUseSession2  = true;   // activar ventana de mañana
input int    InpHourStart2   = 6;      // 06:00 UTC FIJO (AMP srv=UTC, sin DST) — mañana
input int    InpMinStart2    = 0;
input int    InpHourEnd2     = 14;     // 14:00 UTC FIJO (misma ventana UTC del backtest)
input int    InpMinEnd2      = 0;
input bool   InpForceClose2  = false;  // mañana cierra por TP fijo, sin cierre forzado

input group "=== Sesion 3 (16:30-17:00 ET = 23:30-24:00 srv, FIJA) — CIERRE SEGURO ==="
input bool   InpUseSession3  = false;  // operar esta franja: solo tras backtestearla (su FIN ya se usa como cierre seguro)
input int    InpHourStart3   = 16;     // 16:30 ET (anclado US-DST en UTC)
input int    InpMinStart3    = 30;
input int    InpHourEnd3     = 17;     // 17:00 ET = fin de dia (22:00 UTC inv / 21:00 ver)
input int    InpMinEnd3      = 0;
input double InpSL_C         = 10.0;   // [CIERRE] stop (provisional)
input double InpTP_C         = 12.0;   // [CIERRE] TP (provisional)

input group "=== CIERRE SEGURO (no overnight, evita halt CME) ==="
input bool   InpForceClose       = true;  // cerrar la posicion antes del fin del dia (17:00 ET)
input int    InpCloseBufferMin   = 1;     // cerrar y dejar de abrir N min ANTES del cierre
input bool   InpCloseEachSession = false; // true: cerrar tambien al acabar NY y la mañana

input group "=== Visualizacion ==="
input bool   InpDrawBands  = true;       // Dibujar carriles M3 en el grafico
input bool   InpDrawATR    = true;       // Dibujar ATR en ventana separada
input bool   InpDrawArrows = true;       // Flecha en cada entrada
input int    InpVisualBars = 600;        // Cuantas velas M1 hacia atras dibujar
input color  InpColUp      = clrTomato;     // Color carril superior
input color  InpColLo      = clrDodgerBlue; // Color carril inferior
input color  InpColATROK   = clrLime;        // Color ATR OK
input color  InpColATRBlk  = clrRed;         // Color ATR bloqueado
input color  InpColSesOn   = clrDeepSkyBlue; // Color sesion activa
input color  InpColSesOff  = clrSilver;      // Color sesion fuera

input group "=== General ==="
input double InpLots  = 1.0;           // 1 contrato MNQ (AMP)
input long   InpMagic = 770003;        // AMP (MNQ)
input bool   InpLog   = true;

input group "=== ESCALERA (solo MAÑANA) — config del backtest MARTI ==="
// Politica por peldaño: LOTE y TP propios, SL comun. Default = TPLAD5 SL12
// (la menos mala del explorador: lote FIJO 0.1, el TP crece tras cada
// perdida para recuperar; NO sube lotaje). Para escalera de lotes o la
// hibrida HIBA, cambia lotes/TPs aqui. OJO: NINGUNA politica paso el
// estandar de subperiodos en el backtest — demo/forward antes de real.
input bool   InpLadderOn       = false; // KEEPER: escalera OFF (sin martingala, 1 entrada lote fijo). Auditoria 20jun: escalera = leverage, mismo PF, 3x DD
input double InpLadderSL       = 8.0;   // SL comun de la escalera (puntos) — base original
input double InpLadderL1       = 1.0;   // lote peldaño 1 (1 contrato MNQ, FIJO)
input double InpLadderL2       = 1.0;   // lote peldaño 2
input double InpLadderL3       = 1.0;   // lote peldaño 3
input double InpLadderL4       = 1.0;   // lote peldaño 4
input double InpLadderL5       = 1.0;   // lote peldaño 5 (sin uso si MaxRung=4)
input double InpLadderTP1      = 12.0;  // TP p1 = beneficio base del ciclo
input double InpLadderTP2      = 20.0;  // TP p2 = recupera 1 SL (8) + 12
input double InpLadderTP3      = 28.0;  // TP p3 = recupera 2 SL (16) + 12
input double InpLadderTP4      = 36.0;  // TP p4 = recupera 3 SL (24) + 12
input double InpLadderTP5      = 44.0;  // TP p5 = recupera 4 SL (32) + 12 (si MaxRung=5)
input int    InpLadderMaxRung  = 4;     // nº de peldaños activos (perder los 4 = -32 pts)
input double InpLadderMaxLot   = 1.0;   // tope duro de lote (1 contrato MNQ, FIJO)
input bool   InpLadderTickEntry= true;  // escalera: entrar por TICK al tocar carril (no esperar cierre M1)
input int    InpMaxBlownPerDay = 1;     // ciclos completos perdidos por dia antes de PARAR la mañana
input bool   InpLadderResetDay = true;  // cada dia empieza en el peldaño 1

//--- handles
int hUp=INVALID_HANDLE, hLo=INVALID_HANDLE, hATR=INVALID_HANDLE;
//--- ATR subwindow
int    g_atrWin = -1;
string g_atrName = "TM_ATR_M3";
//--- estado
Zone   g_prevZone = Z_NONE;
int    g_fileH = INVALID_HANDLE;
int    g_touchUp=0, g_touchLo=0, g_sessionDay=-1;
//--- cooldown: no abrir mas de una posicion por vela M3
datetime g_lastEntryBarM3=0;  // iTime(M3,0) de la ultima entrada; 0 = nunca
// ── ANTI-DOBLE-LOTE (de la v4) ──
bool     g_orderInFlight=false;  // true desde que mandamos orden hasta confirmar posicion
datetime g_inFlightSince=0;      // sello de tiempo del flag: timeout de seguridad
//--- estado de la escalera
int    g_rung=0;          // peldaño actual (0 = base)
int    g_blownToday=0;    // ciclos completos perdidos hoy
int    g_ladderDay=-1;    // dia del ultimo reset
ulong  g_posID=0;
int    g_scenario=0, g_dir=0, g_regime=0;
double g_entry=0, g_best=0, g_mfe=0, g_mae=0, g_arrvel=0;
double g_atr=0, g_slope=0, g_railgap=0;
int    g_touchN=0;
bool   g_trailOn=false;
datetime g_lastBandBar=0;
string g_prefix="TMB_";          // prefijo objetos carriles
string g_lblTitle="TMB_LBL_TIT"; // titulo
string g_lblATR ="TMB_LBL_ATR";  // ATR valor
string g_lblSES ="TMB_LBL_SES";  // franja NY
string g_lblSES2="TMB_LBL_SES2"; // franja MAÑANA
string g_lblSES3="TMB_LBL_SES3"; // franja CIERRE 16:30-17:00
string g_lblSTA ="TMB_LBL_STA";  // estado operativo
string g_lblPos ="TMB_LBL_POS";  // datos de la posicion (entry/SL/TP)
string g_lblPnL ="TMB_LBL_PNL";  // P&L en vivo
string g_lineEntry="TMB_LINE_ENTRY"; // linea punteada carril entrada
string g_lineTP   ="TMB_LINE_TP";   // linea punteada objetivo (TP/trail-start)
string g_lineSL   ="TMB_LINE_SL";   // linea punteada del stop

//+------------------------------------------------------------------+
int OnInit()
  {
   // ── Fondo del grafico: gris muy oscuro, casi negro pero no negro puro ──
   // El EA NO modifica los colores del grafico: se respeta el tema del usuario.
   ChartRedraw(0);

   hUp  = iMA(_Symbol, PERIOD_M3, InpRailPeriod, 0, MODE_SMA, PRICE_HIGH);
   hLo  = iMA(_Symbol, PERIOD_M3, InpRailPeriod, 0, MODE_SMA, PRICE_LOW);
   hATR = iATR(_Symbol, PERIOD_M3, InpATRPeriod);
   if(hUp==INVALID_HANDLE || hLo==INVALID_HANDLE || hATR==INVALID_HANDLE)
     { Print("Error handles"); return(INIT_FAILED); }

   trade.SetExpertMagicNumber(InpMagic);
   trade.SetTypeFillingBySymbol(_Symbol);

   if(InpDrawATR) SetupATRWindow();
   CreateATRLabel();   // leyenda ATR en el grafico principal
   if(!MQLInfoInteger(MQL_TESTER)) EventSetTimer(1);  // refresco cada 1s en real/demo

   // Log de configuracion al arrancar
   Print(StringFormat("[TM_INIT] Ses1=%s %02d:%02d-%02d:%02d | Ses2=%s %02d:%02d-%02d:%02d | ForceClose=%s | ATRmax=%.1f | Trail=%.0f/Start=%.0f | Lots=%.2f",
         InpUseSession?"ON":"OFF",InpHourStart,InpMinStart,InpHourEnd,InpMinEnd,
         InpUseSession2?"ON":"OFF",InpHourStart2,InpMinStart2,InpHourEnd2,InpMinEnd2,
         InpForceClose2?"ON":"OFF",InpATRMax,InpTrailPoints,InpTrailStart,InpLots));

   if(InpLog)
     {
      g_fileH=FileOpen("TM_BANDAS_trades.csv", FILE_WRITE|FILE_CSV|FILE_ANSI, ',');
      if(g_fileH!=INVALID_HANDLE)
         FileWrite(g_fileH,"time_open","scenario","dir","entry","exit","pnl_pts",
                   "mfe","mae","arr_vel","atr","slope","touch_n","railgap");
     }
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   if(!MQLInfoInteger(MQL_TESTER)) EventKillTimer();
   if(g_fileH!=INVALID_HANDLE) FileClose(g_fileH);
   if(hUp!=INVALID_HANDLE)  IndicatorRelease(hUp);
   if(hLo!=INVALID_HANDLE)  IndicatorRelease(hLo);
   if(hATR!=INVALID_HANDLE) IndicatorRelease(hATR);
   ObjectsDeleteAll(0, g_prefix);
   ObjectDelete(0, g_lblTitle);
   ObjectDelete(0, g_lblATR);
   ObjectDelete(0, g_lblSES);
   ObjectDelete(0, g_lblSES2);
   ObjectDelete(0, g_lblSES3);
   ObjectDelete(0, g_lblSTA);
   ObjectDelete(0, g_lblPos);
   ObjectDelete(0, g_lblPnL);
   ObjectDelete(0, "TMB_LBL_BG");
   ObjectDelete(0, "TMB_LBL_TBAR");
   ObjectDelete(0, g_lineEntry);
   ObjectDelete(0, g_lineTP);
   ObjectDelete(0, g_lineSL);
   ChartRedraw(0);
   // borra ventana ATR
   int w=ChartWindowFind(0, g_atrName);
   if(w>0) ChartIndicatorDelete(0, w, g_atrName);
  }

//+------------------------------------------------------------------+
//| OnTimer: refresca la leyenda cada segundo aunque NO lleguen ticks|
//| (esto arregla que la leyenda "desaparezca" en pausas de mercado) |
//+------------------------------------------------------------------+
void OnTimer()
  {
   if(MQLInfoInteger(MQL_OPTIMIZATION)) return;
   // si por cualquier motivo se borraron los labels, recrearlos
   if(ObjectFind(0,g_lblATR)<0) CreateATRLabel();
   UpdateATRLabel();
  }

//+------------------------------------------------------------------+
//| Helper: crea un OBJ_LABEL en esquina superior derecha           |
//+------------------------------------------------------------------+
void MakeLabel(const string name, const int ydist, const int fontsize, const color col, const string txt)
  {
   ObjectDelete(0, name);
   if(!ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0)) return;
   ObjectSetInteger(0, name, OBJPROP_CORNER,     CORNER_LEFT_LOWER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE,  18);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE,  ydist);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE,   fontsize);
   ObjectSetString (0, name, OBJPROP_FONT,       "Arial Bold");
   ObjectSetInteger(0, name, OBJPROP_COLOR,      col);
   ObjectSetString (0, name, OBJPROP_TEXT,       txt);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN,     true);
   ObjectSetInteger(0, name, OBJPROP_BACK,       false);
   ObjectSetInteger(0, name, OBJPROP_ZORDER,     100);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR,     ANCHOR_LEFT_LOWER);
  }

//+------------------------------------------------------------------+
//| Crea los 3 labels de la leyenda + panel de fondo                 |
//| Disenado para FONDO BLANCO: panel claro, borde gris, texto oscuro|
//| Anclado ABAJO-IZQUIERDA.                                         |
//+------------------------------------------------------------------+
//| Helper: linea horizontal persistente (crea una vez, luego mueve) |
//+------------------------------------------------------------------+
void DrawHLine(const string name, const double price, const color col, const int style, const int width)
  {
   if(ObjectFind(0,name)<0)
     {
      ObjectCreate(0,name,OBJ_HLINE,0,0,price);
      ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,name,OBJPROP_BACK,false);
      ObjectSetInteger(0,name,OBJPROP_ZORDER,50);
     }
   ObjectSetDouble (0,name,OBJPROP_PRICE,price);
   ObjectSetInteger(0,name,OBJPROP_COLOR,col);
   ObjectSetInteger(0,name,OBJPROP_STYLE,style);
   ObjectSetInteger(0,name,OBJPROP_WIDTH,width);
  }

//+------------------------------------------------------------------+
void CreateATRLabel()
  {
   string bg="TMB_LBL_BG";
   ObjectDelete(0,bg);
   if(ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0))
     {
      ObjectSetInteger(0,bg,OBJPROP_CORNER,CORNER_LEFT_LOWER);
      ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,8);
      ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,206);
      ObjectSetInteger(0,bg,OBJPROP_XSIZE,540);
      ObjectSetInteger(0,bg,OBJPROP_YSIZE,200);
      ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,C'248,249,251');  // panel casi blanco
      ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);
      ObjectSetInteger(0,bg,OBJPROP_COLOR,C'90,100,120');      // borde
      ObjectSetInteger(0,bg,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,bg,OBJPROP_BACK,false);
      ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,bg,OBJPROP_ZORDER,90);
     }
   // barra de titulo
   string tbar="TMB_LBL_TBAR";
   ObjectDelete(0,tbar);
   if(ObjectCreate(0,tbar,OBJ_RECTANGLE_LABEL,0,0,0))
     {
      ObjectSetInteger(0,tbar,OBJPROP_CORNER,CORNER_LEFT_LOWER);
      ObjectSetInteger(0,tbar,OBJPROP_XDISTANCE,8);
      ObjectSetInteger(0,tbar,OBJPROP_YDISTANCE,206);
      ObjectSetInteger(0,tbar,OBJPROP_XSIZE,540);
      ObjectSetInteger(0,tbar,OBJPROP_YSIZE,26);
      ObjectSetInteger(0,tbar,OBJPROP_BGCOLOR,C'25,40,75');
      ObjectSetInteger(0,tbar,OBJPROP_BORDER_TYPE,BORDER_FLAT);
      ObjectSetInteger(0,tbar,OBJPROP_COLOR,C'25,40,75');
      ObjectSetInteger(0,tbar,OBJPROP_BACK,false);
      ObjectSetInteger(0,tbar,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,tbar,OBJPROP_ZORDER,91);
     }
   //              nombre      y   font  color     texto
   MakeLabel(g_lblTitle, 186, 11, clrWhite, "TM BANDAS KEEPER  -  SOLO MANANA (S3)");
   MakeLabel(g_lblATR,   158, 15, clrBlack, "ATR(M3): ---");
   MakeLabel(g_lblSES,   134, 10, clrBlack, "NY: ---");
   MakeLabel(g_lblSES2,  114, 10, clrBlack, "Manana: ---");
   MakeLabel(g_lblSES3,   94, 10, clrBlack, "Cierre: ---");
   MakeLabel(g_lblSTA,    70, 11, clrBlack, "Estado: ---");
   MakeLabel(g_lblPos,    46, 10, clrBlack, "Sin posicion");
   MakeLabel(g_lblPnL,    20, 13, clrBlack, "P&L: --");
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Actualiza leyenda completa cada tick                             |
//+------------------------------------------------------------------+
void UpdateATRLabel()
  {
   // Solo omitir en optimizacion, NO en tester visual ni en real
   if(MQLInfoInteger(MQL_OPTIMIZATION)) return;

   // ── ATR en M3 (vela actual, tiempo real) ──────────────────────
   double buf[]; double atrNow=0.0;
   if(CopyBuffer(hATR,0,0,1,buf)>=1) atrNow=buf[0];
   bool  atrOk  = (atrNow > 0.0) && (InpATRMax <= 0.0 || atrNow <= InpATRMax);

   // Si los labels no existen todavia (primera vez), crearlos. El panel
   // completo (ATR + 2 sesiones + estado) se calcula igual en tester y en real.
   // En el tester esta funcion se invoca solo 1 vez por vela M1 (ver OnTick),
   // asi que no ralentiza el visual: lo que lo arrastraba antes era hacerlo
   // cada tick. Por eso aqui ya se puede pintar el panel entero.
   if(ObjectFind(0, g_lblATR) < 0) CreateATRLabel();

   // ── Colores oscuros, legibles sobre el panel claro (fondo blanco)─
   color C_ATR_OK   = C'0,140,0';      // verde oscuro
   color C_ATR_BLOCK= C'200,0,0';      // rojo
   color C_SES_ON   = C'0,90,200';     // azul
   color C_SES_OFF  = C'110,110,110';  // gris
   color C_LISTO    = C'170,110,0';    // ambar oscuro
   color C_BLOQ_ATR = C'200,90,0';     // naranja oscuro
   color C_POS      = C'170,0,150';    // magenta oscuro

   // ── LINEA 1: ATR — grande, verde/rojo segun si bloquea ────────
   string txtATR;
   color  colATR;
   if(atrNow <= 0.0)
     { txtATR = "ATR(M3) = calculando..."; colATR = C'110,110,110'; }
   else
     { txtATR = StringFormat("ATR(M3) = %.1f  /  max %.0f  %s",
                              atrNow, InpATRMax,
                              atrOk ? "[ OK ]" : "[ BLOQUEADO ]");
       colATR = atrOk ? C_ATR_OK : C_ATR_BLOCK; }
   ObjectSetString (0, g_lblATR, OBJPROP_TEXT,  txtATR);
   ObjectSetInteger(0, g_lblATR, OBJPROP_COLOR, colATR);

   // ── Calculo de horario (IC: srv=ET+7 fijo; mañana anclada UTC) ──
   datetime now    = TimeCurrent();
   bool     dstOn  = IsUSDST(now);
   int      offset = dstOn ? 4 : 5;    // AMP srv=UTC: ventanas ET (NY/S3) -> +4 verano / +5 invierno
   int      dst2   = 0;                // ventana 2 (MAÑANA): FIJA en UTC (AMP sin DST)
   MqlDateTime d; TimeToStruct(now, d);
   int curMin = d.hour*60 + d.min;

   // -- Ventana 1 (apertura NY) --
   int ini1 = (InpHourStart + offset)*60 + InpMinStart;
   int fin1 = (InpHourEnd   + offset)*60 + InpMinEnd;
   bool in1 = InpUseSession && curMin>=ini1 && curMin<fin1;
   int  nyLeft = ini1 - curMin;   // minutos hasta apertura NY (para su propia linea)
   // -- Ventana 2 (MAÑANA scalp, servidor fijo) --
   int ini2 = (InpHourStart2 + dst2)*60 + InpMinStart2;
   int fin2 = (InpHourEnd2   + dst2)*60 + InpMinEnd2; if(fin2<=ini2) fin2 += 24*60;
   bool in2 = InpUseSession2 && curMin>=ini2 && curMin<fin2;
   // -- Ventana 3 (CIERRE NY, anclada US-DST) --
   int ini3 = (InpHourStart3 + offset)*60 + InpMinStart3;
   int fin3 = (InpHourEnd3   + offset)*60 + InpMinEnd3; if(fin3<=ini3) fin3 += 24*60;
   bool in3 = InpUseSession3 && curMin>=ini3 && curMin<fin3;
   bool inSes = in1 || in2 || in3;

   // Sesion mas proxima en abrir (de las habilitadas y no activas) para la cuenta atras
   int    minLeft = -1;
   string nextName = "";
   if(InpUseSession  && !in1){ int t=ini1-curMin; if(t<0) t+=1440; if(minLeft<0||t<minLeft){minLeft=t; nextName="NY";} }
   if(InpUseSession2 && !in2){ int t=ini2-curMin; if(t<0) t+=1440; if(minLeft<0||t<minLeft){minLeft=t; nextName="Manana";} }
   if(InpUseSession3 && !in3){ int t=ini3-curMin; if(t<0) t+=1440; if(minLeft<0||t<minLeft){minLeft=t; nextName="Cierre";} }

   // ── LINEA 2: Sesion 1 (apertura NY) ───────────────────────────
   string txtSes1;
   if(InpUseSession)
     {
      string extra1;
      if(in1)             extra1 = StringFormat("cierra %02d:%02d srv", fin1/60, fin1%60);
      else if(nyLeft>0)  extra1 = StringFormat("abre en %dh %02dm", nyLeft/60, nyLeft%60);
      else                extra1 = "cerrada hoy";
      txtSes1 = StringFormat("NY apertura  %02d:%02d-%02d:%02d srv  | SL %.0f/trail+%.0f |  %s  |  %s",
                             ini1/60, ini1%60, fin1/60, fin1%60, InpSLPoints, InpTrailStart,
                             in1 ? "ACTIVA" : "fuera", extra1);
     }
   else txtSes1 = "NY apertura  —  OFF";
   ObjectSetString (0, g_lblSES, OBJPROP_TEXT,  txtSes1);
   ObjectSetInteger(0, g_lblSES, OBJPROP_COLOR, in1 ? C_SES_ON : C_SES_OFF);

   // ── LINEA 3: Sesion 2 (cierre NY = 16:30-17:00 ET) ────────────
   string txtSes2;
   if(InpUseSession2)
     {
      int i2 = ini2 % (24*60), f2 = fin2 % (24*60);
      string ladderTxt;
      if(InpLadderOn)
        {
         int rungShow = g_rung + 1;
         int lossesSoFar = g_rung;
         if(lossesSoFar==0)
            ladderTxt = StringFormat("Escalera: peldaño %d/%-d  [0 perdidas, ciclo limpio]", rungShow, InpLadderMaxRung);
         else if(lossesSoFar==1)
            ladderTxt = StringFormat("Escalera: peldaño %d/%-d  [1 perdida]", rungShow, InpLadderMaxRung);
         else
            ladderTxt = StringFormat("Escalera: peldaño %d/%-d  [%d perdidas]", rungShow, InpLadderMaxRung, lossesSoFar);
         if(g_blownToday>0)
            ladderTxt += StringFormat("  |  ciclos quemados hoy: %d/%d", g_blownToday, InpMaxBlownPerDay);
        }
      else ladderTxt = StringFormat("SL %.0f/TP %.0f (escalera OFF)", InpSL_M, InpTP_M);
      txtSes2 = StringFormat("MAÑANA  %02d:%02d-%02d:%02d srv  |  %s  |  %s",
                             i2/60, i2%60, f2/60, f2%60, ladderTxt, in2 ? "ACTIVA" : "fuera");
     }
   else txtSes2 = "MAÑANA scalp   —  OFF";
   ObjectSetString (0, g_lblSES2, OBJPROP_TEXT,  txtSes2);
   ObjectSetInteger(0, g_lblSES2, OBJPROP_COLOR, in2 ? C_SES_ON : C_SES_OFF);

   // ── Franja CIERRE (16:30-17:00 ET) ──
   string txtSes3;
   if(InpUseSession3)
      txtSes3 = StringFormat("Cierre  %02d:%02d-%02d:%02d srv  | SL %.0f/TP %.0f |  %s",
                             (ini3%(24*60))/60, ini3%60, (fin3%(24*60))/60, fin3%60,
                             InpSL_C, InpTP_C, in3 ? "ACTIVA" : "fuera");
   else txtSes3 = StringFormat("Cierre seguro 17:00 ET  |  buffer %d min  |  %s",
                               InpCloseBufferMin, InpForceClose?"ON":"OFF");
   ObjectSetString (0, g_lblSES3, OBJPROP_TEXT,  txtSes3);
   ObjectSetInteger(0, g_lblSES3, OBJPROP_COLOR, in3 ? C_SES_ON : C_SES_OFF);

   // ── LINEA 4: Estado operativo ─────────────────────────────────
   double up=0, lo=0;
   GetRailBuf(hUp, InpRailShift, up);
   GetRailBuf(hLo, InpRailShift, lo);
   double price   = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   Zone   cur     = ZoneOf(price, up, lo);
   string zoneTxt = (cur==Z_ABOVE)?"SOBRE carril SUP":(cur==Z_BELOW)?"BAJO carril INF":"DENTRO de carriles";
   bool   hasPOS  = HasPosition();

   string estadoTxt;
   color  colSta;
   if(hasPOS)
     {
      if(InpLadderOn && g_regime==2)
        {
         double tpActual = LadderTP();
         estadoTxt = StringFormat(">> POSICION ABIERTA <<  peldaño %d/%d  |  SL %.0f / TP %.0f",
                                  g_rung+1, InpLadderMaxRung, InpLadderSL, tpActual);
        }
      else
        estadoTxt = ">> POSICION ABIERTA <<";
      colSta = C_POS;
     }
   else if(!inSes && minLeft>0)
     { estadoTxt = StringFormat("Esperando %s  —  abre en %dh %02dmin", nextName, minLeft/60, minLeft%60); colSta = C_SES_OFF; }
   else if(!inSes)
     { estadoTxt = "Sesion cerrada  —  sin operaciones";  colSta = C_SES_OFF; }
   else if(!atrOk)
     { estadoTxt = StringFormat("ATR %.1f > max %.0f  —  SIN OPERAR (volatilidad alta)", atrNow, InpATRMax); colSta = C_BLOQ_ATR; }
   else
     {
      int rg = CurrentRegime();
      string reg = (rg==1)? StringFormat("NY  SL %.0f/trail +%.0f", InpSLPoints, InpTrailStart)
                 : (rg==2)? StringFormat("Manana S3  SL %.0f/TP %.0f | ATR %.0f-%.0f | rg>=%.0f | tick=%s | %s", InpSL_M, InpTP_M, InpATRMin_M, InpATRMax, InpMinRailGap_M, InpConfirmM1_M?"no(M1)":"si", InpLadderOn?"MARTI":"sin marti")
                 :          StringFormat("Cierre  SL %.0f/TP %.0f", InpSL_C, InpTP_C);
      estadoTxt = StringFormat("LISTO  |  %s  |  Zona: %s", reg, zoneTxt); colSta = C_LISTO;
     }

   ObjectSetString (0, g_lblSTA, OBJPROP_TEXT,  estadoTxt);
   ObjectSetInteger(0, g_lblSTA, OBJPROP_COLOR, colSta);

   // ── Panel de POSICION + P&L + lineas vivas SL/TP ──
   if(hasPOS)
     {
      bool   pLong  = (PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
      double pEntry = PositionGetDouble(POSITION_PRICE_OPEN);
      double pSL    = PositionGetDouble(POSITION_SL);
      double pTP    = PositionGetDouble(POSITION_TP);
      double pCur   = pLong?SymbolInfoDouble(_Symbol,SYMBOL_BID):SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double pPnlPts= pLong?(pCur-pEntry):(pEntry-pCur);
      double pPnlUsd= PositionGetDouble(POSITION_PROFIT);
      string regName= (g_regime==1)?"NY":(g_regime==2)?"MANANA":(g_regime==3)?"CIERRE":"-";
      string tpTxt  = (pTP>0.0)?StringFormat("%.1f",pTP):"trailing";
      ObjectSetString (0, g_lblPos, OBJPROP_TEXT,
         StringFormat("%s %s | Entrada %.1f | SL %.1f | TP %s",
                      regName, pLong?"COMPRA":"VENTA", pEntry, pSL, tpTxt));
      ObjectSetInteger(0, g_lblPos, OBJPROP_COLOR, C_POS);
      ObjectSetString (0, g_lblPnL, OBJPROP_TEXT,
         StringFormat("P&L:  %+.1f pts   =   %+.2f USD", pPnlPts, pPnlUsd));
      ObjectSetInteger(0, g_lblPnL, OBJPROP_COLOR, (pPnlPts>=0)? C'0,140,0' : C'200,0,0');
      // lineas horizontales vivas (persistentes, no parpadean)
      DrawHLine(g_lineSL, pSL, C'200,0,0', STYLE_DASH, 1);
      double objLevel = (pTP>0.0)? pTP : (pLong? pEntry+InpTrailStart : pEntry-InpTrailStart);
      DrawHLine(g_lineTP, objLevel, C'0,140,0', STYLE_DASH, 2);
     }
   else
     {
      ObjectSetString (0, g_lblPos, OBJPROP_TEXT,  "Sin posicion abierta");
      ObjectSetInteger(0, g_lblPos, OBJPROP_COLOR, C'110,110,110');
      ObjectSetString (0, g_lblPnL, OBJPROP_TEXT,  "P&L:  --");
      ObjectSetInteger(0, g_lblPnL, OBJPROP_COLOR, C'110,110,110');
     }

   // ── Linea punteada carril disparador ─────────────────────────
   bool useUp = (InpDir_InsideToUpper!=DIR_OFF || InpDir_AboveToUpper!=DIR_OFF);
   bool useLo = (InpDir_InsideToLower!=DIR_OFF || InpDir_BelowToLower!=DIR_OFF);
   double railTarget;
   if(useUp && useLo)
      railTarget = (MathAbs(price-up) < MathAbs(price-lo)) ? up : lo;
   else if(useUp) railTarget = up;
   else           railTarget = lo;
   ObjectDelete(0, g_lineEntry);
   if(ObjectCreate(0, g_lineEntry, OBJ_HLINE, 0, 0, railTarget))
     {
      ObjectSetInteger(0, g_lineEntry, OBJPROP_COLOR,      clrOrange);
      ObjectSetInteger(0, g_lineEntry, OBJPROP_STYLE,      STYLE_DOT);
      ObjectSetInteger(0, g_lineEntry, OBJPROP_WIDTH,      1);
      ObjectSetInteger(0, g_lineEntry, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, g_lineEntry, OBJPROP_BACK,       false);
      ObjectSetInteger(0, g_lineEntry, OBJPROP_ZORDER,     50);
     }

   // ── LOG diagnostico cada 30 seg (solo en real/demo, no en tester) ──
   static datetime lastPrint=0;
   if(!MQLInfoInteger(MQL_TESTER) && TimeCurrent()-lastPrint >= 30)
     {
      lastPrint=TimeCurrent();
      Print(StringFormat("[TM_DIAG] %s | Sesion:%s | ATR=%.1f(max%.0f):%s | Zona:%s | Pos:%s | ProxApertura:%s",
            TimeToString(TimeCurrent(),TIME_MINUTES),
            inSes?"SI":"NO", atrNow, InpATRMax, atrOk?"OK":"BLOQ",
            zoneTxt, hasPOS?"ABIERTA":"LIBRE",
            (minLeft>0&&!inSes)?StringFormat("%dh%02dm",minLeft/60,minLeft%60):"--"));
     }

   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Crea la ventana separada del ATR(M3)                             |
//+------------------------------------------------------------------+
void SetupATRWindow()
  {
   // Usa el handle ATR ya creado en M3; lo adjunta a una subventana
   g_atrWin = (int)ChartGetInteger(0, CHART_WINDOWS_TOTAL); // siguiente subventana
   if(!ChartIndicatorAdd(0, g_atrWin, hATR))
     {
      // si falla, reintenta en subventana 1
      ChartIndicatorAdd(0, 1, hATR);
      g_atrWin = 1;
     }
  }

//+------------------------------------------------------------------+
double GetRailBuf(const int handle, const int shift, double &val)
  {
   double b[];
   if(CopyBuffer(handle,0,shift,1,b)<1) return(false);
   val=b[0]; return(true);
  }

//+------------------------------------------------------------------+
//| Dibuja los carriles M3 como ESCALON sobre el grafico actual.     |
//| Para cada vela M1 visible, busca el valor del carril M3 vigente  |
//| en ese instante y lo pinta como segmento horizontal (trend obj). |
//+------------------------------------------------------------------+
void DrawBands()
  {
   if(!InpDrawBands) return;
   // solo redibuja al cambiar de vela M3 (no M1) para no saturar el tester
   datetime tM3=iTime(_Symbol, PERIOD_M3, 0);
   if(tM3==g_lastBandBar) return;
   g_lastBandBar=tM3;

   ObjectsDeleteAll(0, g_prefix);

   // En backtesting visual limitar a 80 velas para no ralentizar
   int bars = MQLInfoInteger(MQL_TESTER) ? 80 : InpVisualBars;
   double up[],lo[]; datetime tm3[];
   // copia suficientes valores M3 (cada vela M3 = 3 de M1)
   int need = bars/3 + InpRailShift + InpRailPeriod + 5;
   if(CopyBuffer(hUp,0,0,need,up)<need) return;
   if(CopyBuffer(hLo,0,0,need,lo)<need) return;
   if(CopyTime(_Symbol,PERIOD_M3,0,need,tm3)<need) return;
   ArraySetAsSeries(up,true); ArraySetAsSeries(lo,true); ArraySetAsSeries(tm3,true);

   // dibuja un segmento por cada vela M3 (escalon): de inicio a fin de esa vela M3
   for(int i=InpRailShift; i<need-1 && i<bars/3+InpRailShift; i++)
     {
      datetime tA=tm3[i];
      datetime tB=tm3[i-1];   // siguiente vela M3 (mas reciente)
      if(tB<=tA) tB=tA+180;
      // carril superior
      string nU=g_prefix+"U"+(string)i;
      ObjectCreate(0,nU,OBJ_TREND,0,tA,up[i],tB,up[i]);
      ObjectSetInteger(0,nU,OBJPROP_COLOR,InpColUp);
      ObjectSetInteger(0,nU,OBJPROP_WIDTH,2);
      ObjectSetInteger(0,nU,OBJPROP_RAY_RIGHT,false);
      ObjectSetInteger(0,nU,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nU,OBJPROP_BACK,true);
      // carril inferior
      string nL=g_prefix+"L"+(string)i;
      ObjectCreate(0,nL,OBJ_TREND,0,tA,lo[i],tB,lo[i]);
      ObjectSetInteger(0,nL,OBJPROP_COLOR,InpColLo);
      ObjectSetInteger(0,nL,OBJPROP_WIDTH,2);
      ObjectSetInteger(0,nL,OBJPROP_RAY_RIGHT,false);
      ObjectSetInteger(0,nL,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nL,OBJPROP_BACK,true);
     }
  }

//+------------------------------------------------------------------+
//| Marca una flecha en la entrada                                   |
//+------------------------------------------------------------------+
void DrawArrow(const bool isBuy, const double price)
  {
   if(!InpDrawArrows) return;
   string nm=g_prefix+"A"+(string)(datetime)TimeCurrent();
   ObjectCreate(0,nm,OBJ_ARROW,0,TimeCurrent(),price);
   ObjectSetInteger(0,nm,OBJPROP_ARROWCODE, isBuy?233:234);
   ObjectSetInteger(0,nm,OBJPROP_COLOR, isBuy?clrLime:clrRed);
   ObjectSetInteger(0,nm,OBJPROP_WIDTH,2);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
  }

//+------------------------------------------------------------------+
double GetATR()
  {
   double b[];
   if(CopyBuffer(hATR,0,InpRailShift,1,b)<1) return(0.0);
   return(b[0]);
  }

double RailSlope(const int scenario)
  {
   double u[],l[]; int n=InpSlopeBarsM3; if(n<1) n=1;
   if(CopyBuffer(hUp,0,InpRailShift,n+1,u)<n+1) return(0.0);
   if(CopyBuffer(hLo,0,InpRailShift,n+1,l)<n+1) return(0.0);
   double midNow=(u[n]+l[n])/2.0, midPast=(u[0]+l[0])/2.0;
   double slope=(midNow-midPast)/(double)n;
   return((scenario==1||scenario==3)? slope : -slope);
  }

double ArrivalVelocity(const int scenario)
  {
   int n=InpVelLookbackBars; if(n<1) n=1;
   double pNow=iClose(_Symbol,PERIOD_M1,0), pPast=iClose(_Symbol,PERIOD_M1,n);
   if(pNow<=0||pPast<=0) return(0.0);
   double disp=pNow-pPast;
   return(((scenario==1||scenario==3)? disp : -disp)/(double)n);
  }

//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
bool IsUSDST(const datetime t)
  {
   MqlDateTime d; TimeToStruct(t,d);
   int m=d.mon, day=d.day, yr=d.year;
   if(m<3||m>11) return(false);
   if(m>3&&m<11) return(true);
   MqlDateTime d1; d1.year=yr; d1.mon=m; d1.day=1; d1.hour=12; d1.min=0; d1.sec=0;
   datetime t1=StructToTime(d1); MqlDateTime dw; TimeToStruct(t1,dw);
   int dow=dw.day_of_week; int firstSun=(dow==0)?1:(8-dow);
   if(m==3)  return(day>=(firstSun+7));
   if(m==11) return(day<firstSun);
   return(false);
  }

// AMP (srv=UTC). 1 = NY 09:30-11:30 ET (eo=+5 inv/+4 ver) ;
// 2 = MAÑANA 06:00-14:00 UTC FIJA ; 3 = cierre 16:30-17:00 ET ; 0 = fuera. NY prioridad.
int CurrentRegime()
  {
   datetime now=TimeCurrent();
   MqlDateTime d; TimeToStruct(now,d);
   int cur=d.hour*60+d.min;

   // -- Ventana 1: apertura NY (FIJA: srv IC = ET+7 todo el año) --
   if(InpUseSession)
     {
      int eo=IsUSDST(now)?4:5;                       // AMP: ET->UTC (+4 ver / +5 inv)
      int ini1=(InpHourStart+eo)*60+InpMinStart;
      int fin1=(InpHourEnd  +eo)*60+InpMinEnd;
      if(cur>=ini1 && cur<fin1) return(1);
     }

   // -- Ventana 2: MAÑANA (anclada UTC: +1h en verano USA) --
   if(InpUseSession2)
     {
      int off2=0;                                   // AMP: mañana FIJA en UTC (sin DST)
      int ini2=(InpHourStart2+off2)*60+InpMinStart2;
      int fin2=(InpHourEnd2  +off2)*60+InpMinEnd2;
      if(fin2<=ini2) fin2+=24*60;
      if(cur>=ini2 && cur<fin2) return(2);
     }

   // -- Ventana 3: CIERRE NY (FIJA en srv, igual que NY) --
   if(InpUseSession3)
     {
      int eo=IsUSDST(now)?4:5;                       // AMP: ET->UTC
      int ini3=(InpHourStart3+eo)*60+InpMinStart3;
      int fin3=(InpHourEnd3  +eo)*60+InpMinEnd3;
      if(fin3<=ini3) fin3+=24*60;
      if(cur>=ini3 && cur<fin3) return(3);
     }

   return(0);
  }

bool InSession() { return(CurrentRegime()!=0); }

// ── Cierre seguro: estar PLANO y no abrir cerca del fin del dia ──
// AMP (srv=UTC): fin de dia = 17:00 ET = 22:00 UTC (inv) / 21:00 UTC (ver).
// Ya no hay halt CME, pero evita el swap nocturno y la madrugada ilíquida.
bool InFlattenZone()
  {
   if(!InpForceClose) return(false);
   datetime now=TimeCurrent();
   MqlDateTime d; TimeToStruct(now,d);
   int cur=d.hour*60+d.min;
   int buf=(InpCloseBufferMin>0)?InpCloseBufferMin:1;

   // Cutoff diario = fin de la ventana de cierre (24:00 srv = 17:00 ET), FIJO.
   int eo=IsUSDST(now)?4:5;                          // AMP: ET->UTC
   int dayEnd=(InpHourEnd3+eo)*60+InpMinEnd3;        // 17:00 ET -> 22:00 (inv) / 21:00 (ver) UTC
   if(dayEnd==0) dayEnd=24*60;           // si el input es 00:00, tratar como fin de dia
   if(cur >= dayEnd-buf) return(true);   // plano el resto del dia

   // Opcional: cerrar tambien al acabar cada sesion de trading
   if(InpCloseEachSession)
     {
      int finNY=(InpHourEnd+eo)*60+InpMinEnd;   // fin NY (ET->UTC)
      int iniNY=(InpHourStart+eo)*60+InpMinStart;
      int off2=0;                                   // AMP: mañana FIJA en UTC (sin DST)
      int finM =(InpHourEnd2+off2)*60+InpMinEnd2; // fin mañana (anclada UTC)
      if(cur>=finM-buf  && cur<iniNY)  return(true); // tras la mañana
      if(cur>=finNY-buf && cur<dayEnd) return(true); // tras NY
     }
   return(false);
  }

Zone ZoneOf(const double p,const double up,const double lo)
  { if(p>up) return(Z_ABOVE); if(p<lo) return(Z_BELOW); return(Z_INSIDE); }

bool HasPosition()
  {
   // Robusto: cuenta SOLO posiciones de NUESTRO magic en este simbolo.
   for(int p=PositionsTotal()-1;p>=0;p--)
     {
      ulong tk=PositionGetTicket(p);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      return(true);
     }
   return(false);
  }

// Volumen NETO de NUESTRO magic en este simbolo: detecta si ya hay posicion
// aunque HasPosition tarde en verla, para no acumular lote.
double NetVolume()
  {
   double v=0;
   for(int p=PositionsTotal()-1;p>=0;p--)
     {
      ulong tk=PositionGetTicket(p);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      v += PositionGetDouble(POSITION_VOLUME);
     }
   return(v);
  }

// Ajusta un precio a la rejilla de tick del simbolo (MNQ = 0.25). Lee SYMBOL_TRADE_TICK_SIZE.
double SnapToTick(const double price)
  {
   double ts=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(ts<=0.0) return(NormalizeDouble(price,_Digits));
   return(NormalizeDouble(MathRound(price/ts)*ts,_Digits));
  }

// LOCK ENTRE INSTANCIAS (variable global del terminal, atomica). Impide que
// dos EAs con el mismo magic (dos graficos) abran en la MISMA vela M3.
bool AcquireBarLock(const datetime bar)
  {
   string nm=StringFormat("TMB_LOCK_%I64d_%I64d",(long)InpMagic,(long)bar);
   if(!GlobalVariableCheck(nm))
      GlobalVariableTemp(nm);
   if(!GlobalVariableSetOnCondition(nm,1.0,0.0))
      return(false);
   string old=StringFormat("TMB_LOCK_%I64d_%I64d",(long)InpMagic,(long)(bar-180));
   if(GlobalVariableCheck(old)) GlobalVariableDel(old);
   return(true);
  }

//+------------------------------------------------------------------+
// ── ESCALERA: lote del peldaño actual, normalizado al step del broker ──
void LadderDayReset()
  {
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   if(d.day!=g_ladderDay)
     {
      g_ladderDay=d.day;
      g_blownToday=0;
      if(InpLadderResetDay && g_rung!=0)
        { Print(StringFormat("[TM_LADDER] Nuevo dia: reset peldaño %d -> 1",g_rung+1)); g_rung=0; }
     }
  }

double LadderLot()
  {
   double L=InpLadderL1;
   if(g_rung==1) L=InpLadderL2;
   else if(g_rung==2) L=InpLadderL3;
   else if(g_rung==3) L=InpLadderL4;
   else if(g_rung>=4) L=InpLadderL5;
   L=MathMin(L,InpLadderMaxLot);                 // tope duro del usuario
   // normalizar al volumen valido del simbolo
   double vmin =SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double vmax =SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double vstep=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(vstep>0) L=MathRound(L/vstep)*vstep;
   L=MathMax(vmin,MathMin(vmax,L));
   return(NormalizeDouble(L,2));
  }

double LadderTP()
  {
   if(g_rung==1) return(InpLadderTP2);
   if(g_rung==2) return(InpLadderTP3);
   if(g_rung==3) return(InpLadderTP4);
   if(g_rung>=4) return(InpLadderTP5);
   return(InpLadderTP1);
  }

// Actualiza el peldaño tras cerrar una operacion de MAÑANA
void LadderOnClose(const double pnlPts)
  {
   if(!InpLadderOn) return;
   int maxR=MathMax(1,MathMin(5,InpLadderMaxRung));
   if(pnlPts>=0.0)
     {
      if(g_rung>0) Print(StringFormat("[TM_LADDER] GANA en peldaño %d: ciclo recuperado, reset -> 1",g_rung+1));
      g_rung=0;
     }
   else
     {
      g_rung++;
      if(g_rung>=maxR)
        {
         g_blownToday++;
         Print(StringFormat("[TM_LADDER] CICLO PERDIDO (%d perdidas seguidas). Quemados hoy: %d/%d. Reset -> 1",
               maxR,g_blownToday,InpMaxBlownPerDay));
         g_rung=0;
        }
      else
         Print(StringFormat("[TM_LADDER] Perdida: sube a peldaño %d (lote %.2f)",g_rung+1,LadderLot()));
     }
  }

//+------------------------------------------------------------------+
void OpenScenario(const int scenario,const ScenDir dir,const double up,const double lo)
  {
   if(dir==DIR_OFF)
     { Print(StringFormat("[TM_BLOCK] S%d DIR_OFF",scenario)); return; }
   int regime=CurrentRegime();
   if(regime==0)
     { Print(StringFormat("[TM_BLOCK] S%d FUERA_SESION hora=%s",scenario,TimeToString(TimeCurrent(),TIME_MINUTES))); return; }
   if(InFlattenZone())
     { Print(StringFormat("[TM_BLOCK] S%d ZONA_CIERRE (fin de dia en <=%d min) hora=%s",scenario,InpCloseBufferMin,TimeToString(TimeCurrent(),TIME_MINUTES))); return; }

   double vel=ArrivalVelocity(scenario);
   if(InpVelFilterMode==1 && vel<InpVelMin)
     { Print(StringFormat("[TM_BLOCK] S%d VEL_MIN vel=%.2f min=%.2f",scenario,vel,InpVelMin)); return; }
   if(InpVelFilterMode==2 && vel>InpVelMax)
     { Print(StringFormat("[TM_BLOCK] S%d VEL_MAX vel=%.2f max=%.2f",scenario,vel,InpVelMax)); return; }

   double atrNow=GetATR();
   if(InpATRMax>0.0 && atrNow>InpATRMax)
     { Print(StringFormat("[TM_BLOCK] S%d ATR_ALTO atr=%.2f max=%.2f",scenario,atrNow,InpATRMax)); return; }
   if(regime==2 && InpATRMin_M>0.0 && atrNow<InpATRMin_M)
     { Print(StringFormat("[TM_BLOCK] S%d ATR_BAJO_MANANA atr=%.2f min=%.2f",scenario,atrNow,InpATRMin_M)); return; }
   // [GATE KEEPER] railGap minimo en la MAÑANA = ancho de canal M3 (up-lo). Solo entradas con canal estirado.
   if(regime==2 && InpMinRailGap_M>0.0 && (up-lo)<InpMinRailGap_M)
     { Print(StringFormat("[TM_BLOCK] S%d RAILGAP_BAJO_MANANA rg=%.2f min=%.2f",scenario,up-lo,InpMinRailGap_M)); return; }

   bool isBuy=(dir==DIR_BUY);
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK), bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double price=isBuy?ask:bid;

   // ── SL/TP automaticos segun la franja ──
   //   NY (1): SL ancho + trailing (sin TP fijo)
   //   MAÑANA (2): SL corto + TP corto fijo, o ESCALERA si esta activa
   //   CIERRE (3): SL/TP provisionales (sin validar)
   double slPts, tpPts;
   if(regime==1)      { slPts=InpSLPoints; tpPts=0.0;     }
   else if(regime==2) { slPts=InpSL_M;     tpPts=InpTP_M; }
   else               { slPts=InpSL_C;     tpPts=InpTP_C; }

   // ── ESCALERA (solo MAÑANA): lote + SL/TP del peldaño + kill switch diario ──
   LadderDayReset();
   double lots=InpLots;
   if(InpLadderOn && regime==2)
     {
      if(g_blownToday>=InpMaxBlownPerDay)
        { Print(StringFormat("[TM_BLOCK] S%d LADDER_STOP ciclos quemados hoy=%d",scenario,g_blownToday)); return; }
      lots =LadderLot();
      slPts=InpLadderSL;
      tpPts=LadderTP();
     }

   double sl = isBuy? price-slPts : price+slPts;
   double tp = 0.0;
   if(tpPts>0.0) tp = isBuy? price+tpPts : price-tpPts;
   sl = SnapToTick(sl);                           // MNQ: rejilla de tick 0.25
   if(tp>0.0) tp = SnapToTick(tp);

   // [ANTI-DOBLE] ultima linea de defensa antes de enviar (vol cubre netting)
   if(HasPosition() || NetVolume()>0.0 || g_orderInFlight)
     { Print(StringFormat("[TM_BLOCK] S%d ya hay posicion/orden en vuelo (vol=%.2f)",scenario,NetVolume())); return; }

   // [ANTI-DOBLE ENTRE INSTANCIAS] lock atomico de la vela M3
   datetime barLock=iTime(_Symbol,PERIOD_M3,0);
   if(!AcquireBarLock(barLock))
     { Print(StringFormat("[TM_BLOCK] S%d vela ya bloqueada por otra instancia (magic %I64d)",scenario,(long)InpMagic)); return; }

   g_orderInFlight=true;
   g_inFlightSince=TimeCurrent();
   bool ok=isBuy?trade.Buy(lots,_Symbol,0.0,sl,tp):trade.Sell(lots,_Symbol,0.0,sl,tp);
   if(!ok)
     {
      g_orderInFlight=false; g_inFlightSince=0;
      Print(StringFormat("[TM_ERROR] S%d orden fallida: %d ret=%d",scenario,GetLastError(),trade.ResultRetcode())); return;
     }
   if(HasPosition()) { g_orderInFlight=false; g_inFlightSince=0; }
   else                Print(StringFormat("[TM_WARN] S%d orden ok pero posicion no visible aun (flag retenido)",scenario));

   Print(StringFormat("[TM_OPEN] S%d %s reg=%s lots=%.2f rung=%d price=%.2f sl=%.2f tp=%.2f atr=%.2f",
         scenario, isBuy?"BUY":"SELL", regime==1?"NY":(regime==2?"MANANA":"CIERRE"), lots,
         (InpLadderOn&&regime==2)?g_rung+1:0, price, sl, tp, atrNow));

   g_posID=trade.ResultOrder(); g_scenario=scenario; g_dir=isBuy?1:-1; g_regime=regime;
   g_entry=price; g_best=price; g_mfe=0; g_mae=0; g_arrvel=vel;
   g_atr=atrNow; g_slope=RailSlope(scenario); g_railgap=up-lo;
   if(scenario==1||scenario==3){ g_touchUp++; g_touchN=g_touchUp; }
   else                        { g_touchLo++; g_touchN=g_touchLo; }
   g_trailOn=false;
   DrawArrow(isBuy, price);

   // Linea punteada objetivo: NY = activacion del trailing; MAÑANA/CIERRE = TP
   double objDist = (regime==1)? InpTrailStart : ((regime==2)? ((InpLadderOn)?tpPts:InpTP_M) : InpTP_C);
   double tpLevel = isBuy ? price + objDist : price - objDist;
   ObjectDelete(0, g_lineTP);
   if(ObjectCreate(0, g_lineTP, OBJ_HLINE, 0, 0, tpLevel))
     {
      ObjectSetInteger(0, g_lineTP, OBJPROP_COLOR,      clrGold);
      ObjectSetInteger(0, g_lineTP, OBJPROP_STYLE,      STYLE_DOT);
      ObjectSetInteger(0, g_lineTP, OBJPROP_WIDTH,      2);
      ObjectSetInteger(0, g_lineTP, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, g_lineTP, OBJPROP_BACK,       false);
      ObjectSetInteger(0, g_lineTP, OBJPROP_ZORDER,     50);
     }
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
void ManageOpen()
  {
   if(!HasPosition()) return;
   long type=PositionGetInteger(POSITION_TYPE);
   double entry=PositionGetDouble(POSITION_PRICE_OPEN);
   double curSL=PositionGetDouble(POSITION_SL), tp=PositionGetDouble(POSITION_TP);
   bool isLong=(type==POSITION_TYPE_BUY);
   double price=isLong?SymbolInfoDouble(_Symbol,SYMBOL_BID):SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double prof=isLong?price-entry:entry-price;
   if(prof>g_mfe) g_mfe=prof;
   if(prof<g_mae) g_mae=prof;
   if(isLong){ if(price>g_best) g_best=price; } else { if(price<g_best) g_best=price; }
   if(g_regime!=1) return;   // solo NY hace trailing; la MAÑANA cierra por TP fijo
   double activ=(InpTrailStart>0.0)?InpTrailStart:InpTrailPoints;
   if(!g_trailOn && prof>=activ)
     {
      g_trailOn=true;
      Print(StringFormat("[TM_TRAIL] ACTIVADO prof=%.2f pts | best=%.2f | SL nuevo=%.2f",
            prof, g_best, isLong?g_best-InpTrailPoints:g_best+InpTrailPoints));
     }
   if(g_trailOn)
     {
      double newSL=SnapToTick(isLong?g_best-InpTrailPoints:g_best+InpTrailPoints);
      bool improve=isLong?(newSL>curSL):(newSL<curSL||curSL==0.0);
      if(improve) trade.PositionModify(_Symbol,newSL,tp);
     }
  }

//+------------------------------------------------------------------+
void CheckClosed()
  {
   if(g_posID==0) return;
   if(HasPosition()) return;
   if(HistorySelectByPosition(g_posID))
     {
      double exitPrice=0; datetime topen=0;
      int deals=HistoryDealsTotal();
      for(int i=0;i<deals;i++)
        {
         ulong tk=HistoryDealGetTicket(i);
         long en=HistoryDealGetInteger(tk,DEAL_ENTRY);
         if(en==DEAL_ENTRY_IN)  topen=(datetime)HistoryDealGetInteger(tk,DEAL_TIME);
         if(en==DEAL_ENTRY_OUT) exitPrice=HistoryDealGetDouble(tk,DEAL_PRICE);
        }
      double pnlPts=(g_dir>0)?(exitPrice-g_entry):(g_entry-exitPrice);
      if(InpLog && g_fileH!=INVALID_HANDLE)
         FileWrite(g_fileH,TimeToString(topen),g_scenario,g_dir,g_entry,exitPrice,
                   pnlPts,g_mfe,g_mae,g_arrvel,g_atr,g_slope,g_touchN,g_railgap);
      if(g_regime==2) LadderOnClose(pnlPts);   // la escalera solo escucha a la MAÑANA
     }
   g_posID=0; g_scenario=0; g_dir=0; g_regime=0; g_trailOn=false;
   ObjectDelete(0, g_lineTP);
   ObjectDelete(0, g_lineSL);
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
// Recrea labels cuando el usuario cambia parametros en el panel
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
  {
   if(id == CHARTEVENT_CHART_CHANGE)
     {
      ObjectDelete(0, g_lblATR);
      ObjectDelete(0, g_lblSES);
      ObjectDelete(0, g_lblSES2);
      ObjectDelete(0, g_lblSTA);
      CreateATRLabel();
      UpdateATRLabel();
     }
  }

void OnTick()
  {
   if(BarsCalculated(hUp)<InpRailPeriod+InpRailShift+1) return;
   if(BarsCalculated(hLo)<InpRailPeriod+InpRailShift+1) return;

   double up,lo;
   if(!GetRailBuf(hUp,InpRailShift,up) || !GetRailBuf(hLo,InpRailShift,lo)) return;
   if(up<=0||lo<=0) return;

   MqlDateTime tt; TimeToStruct(TimeCurrent(),tt);
   if(tt.day!=g_sessionDay){ g_sessionDay=tt.day; g_touchUp=0; g_touchLo=0; }

   // Dibuja bandas: en real siempre; en visual tester solo al cambiar vela M3 (rapido)
   if(!MQLInfoInteger(MQL_OPTIMIZATION)) DrawBands();
   // Leyenda: en real el OnTimer la refresca cada 1s. En tester visual solo
   // la actualizamos al cambiar de vela M1 (antes era cada tick + ChartRedraw,
   // y eso es lo que arrastraba el visual). El ATR(M3) no cambia mas fino que esto.
   if(!MQLInfoInteger(MQL_OPTIMIZATION))
     {
      if(MQLInfoInteger(MQL_TESTER))
        {
         static datetime g_lastUiBar=0;
         datetime curM1=iTime(_Symbol,PERIOD_M1,0);
         if(curM1!=g_lastUiBar){ g_lastUiBar=curM1; UpdateATRLabel(); }
        }
      else UpdateATRLabel();
     }

   // Cierre seguro: plano antes del fin del dia (17:00 ET), evita halt CME y overnight.
   if(InFlattenZone() && HasPosition())
     {
      Print(StringFormat("[TM_FCLOSE] Cierre seguro (buffer %d min antes del halt) hora=%s",
            InpCloseBufferMin, TimeToString(TimeCurrent(),TIME_MINUTES)));
      trade.PositionClose(_Symbol);
     }

   // [ANTI-DOBLE] liberar el flag in-flight al confirmar la posicion, o por timeout
   // de 10s si la orden nunca aparecio (para no quedar bloqueado sin operar).
   if(g_orderInFlight)
     {
      if(HasPosition())
        { g_orderInFlight=false; g_inFlightSince=0; }
      else if(g_inFlightSince>0 && TimeCurrent()-g_inFlightSince>10)
        { Print("[TM_WARN] flag in-flight liberado por timeout (posicion nunca aparecio)"); g_orderInFlight=false; g_inFlightSince=0; }
     }

   CheckClosed();
   ManageOpen();

   double price=SymbolInfoDouble(_Symbol,SYMBOL_BID);

   // NY: zona por TICK (validado). MAÑANA con InpConfirmM1_M: zona por CIERRE M1.
   // EXCEPCION: si la escalera esta activa y InpLadderTickEntry, la mañana
   // tambien entra por TICK al tocar el carril (re-entradas inmediatas tras un SL).
   int regNow=CurrentRegime();
   bool ladderTick=(InpLadderOn && InpLadderTickEntry && regNow==2);
   bool useM1=(InpConfirmM1_M && regNow==2 && !ladderTick);

   if(!useM1)
     {
      Zone cur=ZoneOf(price,up,lo);
      if(!HasPosition() && NetVolume()<=0.0 && !g_orderInFlight && g_prevZone!=Z_NONE && cur!=g_prevZone)
        {
         // COOLDOWN: solo una entrada por vela M3 (evita rafagas de SL+reentrada en el mismo tick)
         datetime barM3=iTime(_Symbol,PERIOD_M3,0);
         bool cooldownOK=(barM3!=g_lastEntryBarM3);
         if(cooldownOK)
           {
            if(g_prevZone==Z_INSIDE && cur==Z_ABOVE) OpenScenario(1,InpDir_InsideToUpper,up,lo);
            else if(g_prevZone==Z_INSIDE && cur==Z_BELOW) OpenScenario(2,InpDir_InsideToLower,up,lo);
            else if(g_prevZone==Z_ABOVE && cur==Z_INSIDE) OpenScenario(3,InpDir_AboveToUpper,up,lo);
            else if(g_prevZone==Z_BELOW && cur==Z_INSIDE) OpenScenario(4,InpDir_BelowToLower,up,lo);
            if(HasPosition()) g_lastEntryBarM3=barM3; // actualizar solo si la orden se ejecuto
           }
         else Print("[TM_COOLDOWN] Ya entrado en esta vela M3 (",TimeToString(barM3),") - ignorando señal");
        }
      g_prevZone=cur;
     }
   else g_prevZone=ZoneOf(price,up,lo);

   static datetime g_lastM1=0;
   static Zone     g_prevZoneM1=Z_NONE;
   datetime btM1=iTime(_Symbol,PERIOD_M1,0);
   if(btM1!=g_lastM1)
     {
      g_lastM1=btM1;
      double cM1=iClose(_Symbol,PERIOD_M1,1);
      Zone curM1=ZoneOf(cM1,up,lo);
      if(useM1 && !HasPosition() && NetVolume()<=0.0 && !g_orderInFlight && g_prevZoneM1!=Z_NONE && curM1!=g_prevZoneM1)
        {
         if(g_prevZoneM1==Z_INSIDE && curM1==Z_ABOVE) OpenScenario(1,InpDir_InsideToUpper,up,lo);
         else if(g_prevZoneM1==Z_INSIDE && curM1==Z_BELOW) OpenScenario(2,InpDir_InsideToLower,up,lo);
         else if(g_prevZoneM1==Z_ABOVE && curM1==Z_INSIDE) OpenScenario(3,InpDir_AboveToUpper,up,lo);
         else if(g_prevZoneM1==Z_BELOW && curM1==Z_INSIDE) OpenScenario(4,InpDir_BelowToLower,up,lo);
        }
      g_prevZoneM1=curM1;
     }
  }
//+------------------------------------------------------------------+
