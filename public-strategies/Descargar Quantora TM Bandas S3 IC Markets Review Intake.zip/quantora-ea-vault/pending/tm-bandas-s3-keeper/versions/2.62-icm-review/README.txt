TM BANDAS S3 KEEPER - IC MARKETS REVIEW PACKAGE

STATUS: PENDING BROKER-SPECIFIC VALIDATION

The supplied source is the owner-tested AMP/MNQ v2.61 build. It remains unchanged in the sibling 2.61-amp-mnq folder.

Requested target profile:
- Broker: IC Markets
- Symbol family: USTEC
- Requested volume: 0.10 lots
- Expected tick size supplied by owner: 0.10
- Morning strategy: S3 only
- Ladder: OFF
- Entry: tick-based
- SL: 12 points
- TP: 36 points

Do not mark this target profile as installation-ready until these live account symbol properties are captured and checked:
SYMBOL_TRADE_TICK_SIZE, SYMBOL_VOLUME_MIN, SYMBOL_VOLUME_STEP, SYMBOL_TRADE_TICK_VALUE, SYMBOL_TRADE_CONTRACT_SIZE, account server time and symbol name.

No modified live-trading MQ5 is included in this target folder.
